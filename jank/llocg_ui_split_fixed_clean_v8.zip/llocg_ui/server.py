# -*- coding: utf-8 -*-
from __future__ import annotations

"""llocg_ui.server

HTTP サーバ（/ , /state, /cmd, /img）とフロントHTML。

- `App` が状態（GameState/RNG/DB/ImageLocator）を保持
- `Handler` は stdlib の http.server でルーティング
"""

import json
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlparse, parse_qs, unquote

from .db import load_cards_db
from .images import ImageLocator
from .engine import (
    GameState,
    new_game,
    push_undo, do_undo,
    cmd_play, cmd_set, cmd_yell, cmd_attempt, cmd_ack,
    cmd_end_turn, cmd_next,
    cmd_activate_to_green,
    cmd_resolve_pending,
    trace_write,
    _get_card, _has_sacrifice_ability,
)

def _write_text(path, text, encoding="utf-8"):
    """Write text to path, creating parent dirs."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding=encoding)


HTML = r"""<!doctype html><html><head><meta charset="utf-8"/>
<title>LLCG Manual UI</title>
<style>
body{font-family:system-ui,sans-serif;margin:0}
.wrap{display:grid;grid-template-columns:1fr 380px;height:100vh}
.main{padding:10px;overflow:auto;background:#f7f7f7}
.side{border-left:1px solid #ddd;padding:10px;overflow:auto;background:#fff}
.row{display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap}
.panel{background:#fff;border:1px solid #ddd;border-radius:8px;padding:10px}
.title{font-weight:600;margin-bottom:6px}
.cards{display:flex;gap:6px;flex-wrap:wrap}
.card{width:110px}
.card img{width:90px;border-radius:6px;border:1px solid #ccc}
.card .cap{font-size:12px;line-height:1.2;margin-top:4px}
.stageSlot{width:120px;height:160px;border:2px dashed #aaa;border-radius:10px;display:flex;align-items:center;justify-content:center;background:#fafafa}
.stack{display:flex;align-items:flex-start;gap:0;overflow-x:auto;overflow-y:hidden;padding:4px 4px 10px 4px;min-height:160px}
.stack img{width:120px;position:relative;left:auto;top:auto;border-radius:6px;border:1px solid #ccc;box-shadow:0 1px 2px rgba(0,0,0,.12)}
.stack img + img{margin-left:-80px}
.btn{padding:6px 10px;border:1px solid #999;background:#fff;border-radius:6px;cursor:pointer}
.matWrap{position:relative;width:100%;max-width:1100px;aspect-ratio:1560/851;border:1px solid #ddd;border-radius:10px;overflow:hidden;background:#222;margin-bottom:10px}
.matImg{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:contain;object-position:center;opacity:1}
.zone{position:absolute;border:2px dashed rgba(255,255,255,0.35);border-radius:10px;pointer-events:none}
.zoneInner{position:absolute;inset:0;display:flex;gap:6px;align-items:center;justify-content:flex-start;flex-wrap:nowrap;overflow:hidden;padding:6px;pointer-events:auto}
.zoneInner .card img{width:74px}
.zoneTitle{position:absolute;left:6px;top:6px;font-size:12px;color:#fff;background:rgba(0,0,0,.55);padding:2px 6px;border-radius:6px}
.deckBadge{position:absolute;right:6px;bottom:6px;font-size:12px;color:#fff;background:rgba(0,0,0,.65);padding:2px 6px;border-radius:6px}
.clickSlot{width:120px;height:160px;border:2px dashed rgba(255,255,255,0.55);border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;background:rgba(0,0,0,0.15);pointer-events:auto;cursor:pointer}

.log{font-family:ui-monospace,Menlo,monospace;font-size:12px;white-space:pre-wrap}
.small{font-size:12px;color:#444}
.kbd{font-family:ui-monospace,monospace;background:#eee;padding:1px 6px;border-radius:6px;border:1px solid #ddd}

/* Live cards: rotate clockwise 90deg to match member portrait */
.liveCard{display:flex;align-items:center;justify-content:center;overflow:hidden}
.card.liveCard{width:90px;height:130px}
.card.liveCard img{width:130px;height:auto;transform:rotate(90deg);transform-origin:center}

/* Set zone panel: fixed height, horizontal scroll so Next button doesn't move */
#setZone{flex-wrap:nowrap;overflow-x:auto;overflow-y:hidden;height:150px;align-items:flex-start}
#setZone .card{flex:0 0 auto}

/* Playmat: rotated live cards inside mat zones (smaller) */
.zoneInner .card.liveCard{width:74px;height:110px}
.zoneInner .card.liveCard img{width:110px;height:auto;transform:rotate(90deg);transform-origin:center}

/* Cheer/reveal stack on playmat */
.stackRow{display:flex;align-items:center;justify-content:flex-start;flex-wrap:nowrap;overflow:hidden}
.stackRow .card{flex:0 0 auto}
.stackRow .card + .card{margin-left:-36px}

</style></head><body>
<div class="wrap">
<div class="main">
<div class="panel" style="width:100%;">
  <div class="title">Playmat</div>
  <div class="matWrap" id="matWrap">
    <img class="matImg" src="/playmat" alt="playmat"/>
    <!-- zones (approx; adjust later) -->
    <div class="zone" id="zLive" style="left:19.2%;top:2.4%;width:60.6%;height:25.0%;">
      <div class="zoneTitle">Live set</div>
      <div class="zoneInner" id="matSet"></div>
    </div>
    <div class="zone" id="zStage" style="left:19.2%;top:28.6%;width:60.6%;height:33.2%;">
      <div class="zoneTitle">Stage</div>
      <div class="zoneInner" id="matStage" style="justify-content:space-around;"></div>
    </div>
    <div class="zone" id="zHand" style="left:19.2%;top:63.0%;width:60.6%;height:34.6%;">
      <div class="zoneTitle">Hand</div>
      <div class="zoneInner" id="matHand"></div>
    </div>
    <div class="zone" id="zDeck" style="left:80.4%;top:2.4%;width:18.8%;height:28.0%;">
      <div class="zoneTitle">Deck</div>
      <div class="zoneInner" id="matDeck" style="justify-content:center;"></div>
      <div class="deckBadge" id="matDeckCount"></div>
    </div>

    <div class="zone" id="zReveal" style="left:1.2%;top:29.0%;width:16.8%;height:33.0%;">
      <div class="zoneTitle">Cheer / Reveal</div>
      <div class="zoneInner stackRow" id="matReveal"></div>
    </div>
    <div class="zone" id="zGreen" style="left:80.4%;top:34.2%;width:18.8%;height:33.0%;">
      <div class="zoneTitle">Waiting room</div>
      <div class="zoneInner" id="matGreen" style="justify-content:center;"></div>
      <div class="deckBadge" id="matGreenCount"></div>
    </div>
  </div>
  <div class="small">※ 枠位置は暫定（playmat基準で後で微調整）。左の成功ライブ置き場は背景位置で実質カットしています。</div>
</div>

  <div class="row">
    <div class="panel" style="min-width:420px;">
      <div class="title">Stage</div>
      <div class="row">
        <div class="stageSlot" id="slotL" onclick="slotClick('L')">L</div>
        <div class="stageSlot" id="slotC" onclick="slotClick('C')">C</div>
        <div class="stageSlot" id="slotR" onclick="slotClick('R')">R</div>
      </div>
      <div class="small">Click a hand card → click L/C/R to play.</div>
    </div>

    <div class="panel">
      <div class="title">Resolve Zone (解決領域) / ACK → Green Room (控室)</div>
      <div class="stack" id="resolveStack"></div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="sendCmd('yell', {})">Yell (エール)</button>
        <button class="btn" onclick="sendCmd('ack', {})">ACK (確認→控室)</button>
        <button class="btn" onclick="sendCmd('undo', {})">Undo</button>
      </div>
    </div>

    <div class="panel">
      <div class="title">Set Zone (伏せ)</div>
      <div class="cards" id="setZone"></div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="setSelected()">Set selected (max3)</button>
        <button class="btn" onclick="sendCmd('attempt', {})">Attempt LIVE</button>
        <button class="btn" onclick="sendCmd('end_turn', {})">End Turn</button>
        <button class="btn" onclick="nextStep()">Next</button>
      </div>
    </div>
  </div>

  <div class="panel" style="margin-top:10px;">
    <div class="title">Hand</div>
    <div class="cards" id="hand"></div>
    <div class="small">Selected: <span class="kbd" id="selInfo">none</span></div>
  </div>
</div>

<div class="side">
  <div class="panel">
    <div class="title">Status</div>
    <div class="small" id="statusLine"></div>
    <div class="small" id="countsLine"></div>
    <div class="panel" style="margin-top:10px;">
      <div class="title">Selected Stage</div>
      <div class="small" id="selStageInfo">(click a stage slot)</div>
      <div id="selStageActions" class="row" style="margin-top:8px;"></div>
    </div>
    <div class="panel" style="margin-top:10px;">
      <div class="title">Pending Prompts</div>
      <div class="small" id="pendingBox">(none)</div>
    </div>
    <div class="row" style="margin-top:8px;">
      <button class="btn" onclick="sendCmd('toggle_debug', {})">Toggle Debug</button>
      <button class="btn" onclick="sendCmd('peek', {n:5})">Peek 5</button>
    </div>
  </div>

  <div class="panel" style="margin-top:10px;">
    <div class="title">Log</div>
    <div class="log" id="log"></div>
  </div>
</div>
</div>

<script>
let STATE=null;
let selectedHand=new Set();
let playPick=null;
let selectedStage=null;

function escapeHtml(s){return (s||"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
function imgUrl(cn){return "/img?cn="+encodeURIComponent(cn);}
function labelFor(cn){const m=(STATE&&STATE.cn2name)?STATE.cn2name:{}; const nm=m[cn]; return nm? (nm+" ("+cn+")") : cn;}

function renderMat(){
  const setBox=document.getElementById("matSet");
  const stageBox=document.getElementById("matStage");
  const handBox=document.getElementById("matHand");
  const deckBox=document.getElementById("matDeck");
  const greenBox=document.getElementById("matGreen");
  if(!setBox||!stageBox||!handBox||!deckBox||!greenBox) return;

  setBox.innerHTML="";
  (STATE.set_zone||[]).forEach((cn)=>{
    const d=document.createElement("div");
    d.className="card liveCard";
    const img=document.createElement("img");
    img.src=imgUrl(cn);
    img.title=labelFor(cn);
    d.appendChild(img);
    setBox.appendChild(d);
  });

  stageBox.innerHTML="";
  ["L","C","R"].forEach((p)=>{
    const slot=document.createElement("div");
    slot.className="clickSlot";
    slot.onclick=()=>slotClick(p);
    const v=(STATE.stage||{})[p];
    if(v && v.cardnumber){
      const img=document.createElement("img");
      img.src=imgUrl(v.cardnumber);
      img.title=labelFor(v.cardnumber);
      img.style.width="110px";
      img.style.borderRadius="8px";
      img.style.border="1px solid rgba(255,255,255,0.6)";
      slot.innerHTML="";
      slot.appendChild(img);
    }else{
      slot.textContent=p;
    }
    stageBox.appendChild(slot);
  });

  handBox.innerHTML="";
  (STATE.hand||[]).forEach((cn,idx)=>{
    const div=document.createElement("div");
    div.className="card";
    div.style.opacity= selectedHand.has(idx) ? "1.0" : "0.85";
    div.style.transform= selectedHand.has(idx) ? "translateY(-4px)" : "none";
    div.style.cursor="pointer";
    const img=document.createElement("img");
    img.src=imgUrl(cn);
    img.onclick=()=>handClick(idx);
    img.title=labelFor(cn);
    div.appendChild(img);
    handBox.appendChild(div);
  });

  deckBox.innerHTML="";
  const back=document.createElement("img");
  back.src="/img?cn="+encodeURIComponent("__BACK__");
  back.style.width="110px";
  back.style.borderRadius="8px";
  back.style.border="1px solid rgba(255,255,255,0.6)";
  deckBox.appendChild(back);
  const dc=document.getElementById("matDeckCount");
  if(dc) dc.textContent="x"+((STATE.deck||[]).length);

  greenBox.innerHTML="";
  const gr=STATE.green_room||[];
  const top=gr.length? gr[gr.length-1] : "";
  if(top){
    const img=document.createElement("img");
    img.src=imgUrl(top);
    img.title=labelFor(top);
    img.style.width="110px";
    img.style.borderRadius="8px";
    img.style.border="1px solid rgba(255,255,255,0.6)";
    greenBox.appendChild(img);
  }
  const gc=document.getElementById("matGreenCount");
  if(gc) gc.textContent="x"+gr.length;

  // Reveal / cheer (resolve zone) on playmat (can overlap)
  const revBox=document.getElementById("matReveal");
  if(revBox){
    revBox.innerHTML="";
    (STATE.resolve_zone||[]).forEach((cn)=>{
      const d=document.createElement("div");
      d.className="card";
      const img=document.createElement("img");
      img.src=imgUrl(cn);
      img.title=labelFor(cn);
      d.appendChild(img);
      revBox.appendChild(d);
    });
  }

}

async function fetchState(){
  const r=await fetch("/state");
  STATE=await r.json();
  render();
}

function renderCard(cn, cap){
  const div=document.createElement("div");
  div.className="card";
  const img=document.createElement("img");
  img.src=imgUrl(cn);
  img.onerror=()=>{img.style.display="none";};
  div.appendChild(img);
  const p=document.createElement("div");
  p.className="cap";
  p.innerHTML=escapeHtml(cap);
  div.appendChild(p);
  return div;
}

function render(){
  if(!STATE) return;
  document.getElementById("statusLine").innerText =
    `Turn ${STATE.turn} | Phase=${STATE.phase} | Energy active=${STATE.energy_active} wait=${STATE.energy_wait} | Debug=${STATE.debug}`;
  document.getElementById("countsLine").innerText =
    `Deck=${STATE.deck.length} Hand=${STATE.hand.length} GreenRoom=${STATE.green_room.length} Resolve=${STATE.resolve_zone.length}`;

  ["L","C","R"].forEach(pos=>{
    const el=document.getElementById("slot"+pos);
    el.innerHTML="";
    el.style.outline = (selectedStage===pos ? "3px solid #333" : "none");
    const slot=STATE.stage[pos];
    if(slot && slot.cardnumber){
      const img=document.createElement("img");
      img.src=imgUrl(slot.cardnumber);
      img.style.width="110px";
      img.style.borderRadius="6px";
      img.style.border="1px solid #ccc";
      el.appendChild(img);
    }else{
      el.innerText=pos;
    }
  });

  
  // Selected stage + actions
  const selInfo=document.getElementById("selStageInfo");
  const selActions=document.getElementById("selStageActions");
  selActions.innerHTML="";
  if(!selectedStage){
    selInfo.innerText="(click a stage slot)";
  }else{
    const slot=STATE.stage[selectedStage];
    if(!slot || !slot.cardnumber){
      selInfo.innerText=`${selectedStage}: (empty)`;
    }else{
      const det=(STATE.stage_detail||{})[selectedStage]||{};
      selInfo.innerText=`${selectedStage}: ${det.cardnumber||slot.cardnumber}  ${det.name||""}  [${det.type||""}]`;
      if(det.has_sac){
        const b=document.createElement("button");
        b.className="btn";
        b.innerText="起動：このメンバーを控え室に置く";
        b.onclick=()=>sendCmd("activate_to_green",{pos:selectedStage});
        selActions.appendChild(b);
      }
    }
  }

  // Pending prompts
  const pb=document.getElementById("pendingBox");
  const pend=STATE.pending||[];
  if(!pend.length){
    pb.innerText="(none)";
  }else{
    pb.innerHTML="";
    pend.forEach((p,idx)=>{
      const row=document.createElement("div");
      row.className="row";
      row.style.gap="6px";
      row.style.alignItems="center";

      const t=document.createElement("div");
      t.className="small";
      t.style.flex="1";
      t.innerText=p.text||JSON.stringify(p);
      row.appendChild(t);

if((p.kind||"")==="choose_shioriko_enter"){
  const sel=document.createElement("select");
  sel.className="btn";
  const op1=document.createElement("option"); op1.value="energy"; op1.innerText="エネルギーを1枚アクティブ";
  const op2=document.createElement("option"); op2.value="topdeck"; op2.innerText="虹ヶ咲LIVEを最大2枚デッキ上";
  sel.appendChild(op1); sel.appendChild(op2);
  row.appendChild(sel);
  const go=document.createElement("button");
  go.className="btn";
  go.innerText="Choose";
  go.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});
  row.appendChild(go);
}else if((p.kind||"")==="topdeck_live_from_green"){
  const sel=document.createElement("select");
  sel.className="btn";
  (p.options||[]).forEach((cn)=>{
    const op=document.createElement("option");
    op.value=cn;
    op.innerText=labelFor(cn);
    sel.appendChild(op);
  });
  row.appendChild(sel);
  const put=document.createElement("button");
  put.className="btn";
  put.innerText="Put";
  put.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});
  const no=document.createElement("button");
  no.className="btn";
  no.innerText="Skip";
  no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
  row.appendChild(put);
  row.appendChild(no);
}else if((p.kind||"")==="shioriko_topdeck_pick1" || (p.kind||"")==="shioriko_topdeck_pick2"){
  const sel=document.createElement("select");
  sel.className="btn";
  (p.options||[]).forEach((cn)=>{
    const op=document.createElement("option");
    op.value=cn;
    op.innerText=labelFor(cn);
    sel.appendChild(op);
  });
  row.appendChild(sel);
  const put=document.createElement("button");
  put.className="btn";
  put.innerText="Topdeck";
  put.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});
  const no=document.createElement("button");
  no.className="btn";
  no.innerText="Skip";
  no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
  row.appendChild(put);
  row.appendChild(no);
}else if((p.kind||"")==="pick_live_from_green"){

        const sel=document.createElement("select");
        sel.className="btn";
        (p.options||[]).forEach((cn)=>{
          const op=document.createElement("option");
          op.value=cn;
          op.innerText=labelFor(cn);
          sel.appendChild(op);
        });
        row.appendChild(sel);

        const take=document.createElement("button");
        take.className="btn";
        take.innerText="Take";
        take.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});

        const no=document.createElement("button");
        no.className="btn";
        no.innerText="Skip";
        no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});

        row.appendChild(take);
        row.appendChild(no);
      }else{
        const yes=document.createElement("button");
        yes.className="btn";
        yes.innerText="Pay";
        yes.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"pay"});
        const no=document.createElement("button");
        no.className="btn";
        no.innerText="Skip";
        no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
        row.appendChild(yes);
        row.appendChild(no);
      }

      pb.appendChild(row);
    });
  }

  renderMat();

const rs=document.getElementById("resolveStack");
  rs.innerHTML="";
  const rz=STATE.resolve_zone||[];
  const show=rz.slice(Math.max(0, rz.length-12));
  show.forEach((cn,i)=>{
    const img=document.createElement("img");
    img.src=imgUrl(cn);
    img.style.left=(i*6)+"px";
    img.style.top=(i*4)+"px";
    rs.appendChild(img);
  });

  const sz=document.getElementById("setZone");
  sz.innerHTML="";
  (STATE.set_zone||[]).forEach(cn=>{ const el=renderCard(cn, labelFor(cn)); el.classList.add("liveCard"); sz.appendChild(el); });

  const hand=document.getElementById("hand");
  hand.innerHTML="";
  (STATE.hand||[]).forEach((cn, idx)=>{
    const div=renderCard(cn, `${idx}: ${labelFor(cn)}`);
    if(selectedHand.has(idx)) div.style.outline="3px solid #333";
    div.style.cursor="pointer";
    div.onclick=()=>{
      if(selectedHand.has(idx)) selectedHand.delete(idx);
      else selectedHand.add(idx);
      playPick=idx;
      document.getElementById("selInfo").innerText = Array.from(selectedHand).sort((a,b)=>a-b).join(", ");
      render();
    };
    hand.appendChild(div);
  });

  document.getElementById("log").innerText=(STATE.log||[]).slice(-120).join("\n");
}

function slotClick(pos){
  if(playPick===null){
    selectedStage = (selectedStage===pos ? null : pos);
    render();
    return;
  }
  sendCmd("play",{hand_idx:playPick,pos:pos});
  playPick=null;
  selectedHand.clear();
}

function setSelected(){
  const idxs=Array.from(selectedHand).sort((a,b)=>a-b).slice(0,3);
  sendCmd("set",{indices:idxs});
  selectedHand.clear();
  playPick=null;
}


function nextStep(){
  const idxs=Array.from(selectedHand).sort((a,b)=>a-b).slice(0,3);
  sendCmd("next",{indices:idxs});
  selectedHand.clear();
  playPick=null;
}


async function sendCmd(cmd,payload){
  const body={cmd:cmd,payload:payload||{}};
  const r=await fetch("/cmd",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  STATE=await r.json();
  render();
}

fetchState();
</script>
</body></html>
"""


class App:
    def __init__(
        self,
        root: Path,
        code: str,
        deck_code: str,
        seed: int,
        debug: bool,
        compiled: Optional[Path] = None,
        tokv1: Optional[Path] = None,
    ):
        self.root = root
        self.outdir = root / "sim_out"
        self.cards_db = load_cards_db(root, compiled_path=compiled, tokv1_path=tokv1)
        self.img = ImageLocator(root)
        self.ui_code = str(code)
        self.deck_code = str(deck_code)
        self.gs, self.rng = new_game(root, self.deck_code, seed=seed, debug=debug)
        self.save_trace()

    def save_trace(self):
        self.outdir.mkdir(parents=True, exist_ok=True)
        _write_text(self.outdir / "ui_trace.txt", "\n".join(self.gs.log) + ("\n" if self.gs.log else ""))

    def _cn2name(self) -> Dict[str, str]:
        cns: set = set()
        try:
            cns.update(self.gs.hand or [])
            cns.update(self.gs.green_room or [])
            cns.update(self.gs.set_zone or [])
            cns.update(self.gs.resolve_zone or [])
        except Exception:
            pass
        try:
            for _pos, v in (self.gs.stage or {}).items():
                if v and getattr(v, "cardnumber", None):
                    cns.add(v.cardnumber)
        except Exception:
            pass

        out: Dict[str, str] = {}
        for cn in sorted(cns):
            ci = _get_card(self.cards_db, cn)
            if ci and ci.name:
                out[cn] = ci.name
        return out

    def state_json(self) -> Dict[str, Any]:
        return {
            "root": self.gs.root,
            "code": self.ui_code,
            "deck_code": self.deck_code,
            "seed": self.gs.seed,
            "debug": self.gs.debug,
            "turn": self.gs.turn,
            "phase": self.gs.phase,
            "deck": self.gs.deck if self.gs.debug else ["?"] * len(self.gs.deck),
            "hand": self.gs.hand,
            "energy_active": self.gs.energy_active,
            "energy_wait": self.gs.energy_wait,
            "stage": {k: (asdict(v) if v else None) for k, v in self.gs.stage.items()},
            "green_room": self.gs.green_room,
            "set_zone": self.gs.set_zone,
            "resolve_zone": self.gs.resolve_zone,
            "pending": self.gs.pending,
            "cn2name": self._cn2name(),
            "stage_detail": {k: ({
                "cardnumber": v.cardnumber,
                "name": (_get_card(self.cards_db, v.cardnumber).name if _get_card(self.cards_db, v.cardnumber) else ""),
                "type": (_get_card(self.cards_db, v.cardnumber).type if _get_card(self.cards_db, v.cardnumber) else ""),
                "has_sac": _has_sacrifice_ability(_get_card(self.cards_db, v.cardnumber)),
            } if v else None) for k, v in self.gs.stage.items()},
            "log": self.gs.log,
        }

    def cmd(self, name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        mutating = name in {"play", "set", "yell", "attempt", "ack", "end_turn", "toggle_debug", "activate_to_green", "resolve_pending", "next"}
        if mutating and name != "toggle_debug":
            push_undo(self.gs, self.rng)

        if name == "play":
            cmd_play(self.gs, self.cards_db, int(payload.get("hand_idx", -1)), str(payload.get("pos", "")))
        elif name == "set":
            idxs = payload.get("indices", [])
            if not isinstance(idxs, list):
                idxs = []
            cmd_set(self.gs, self.rng, [int(x) for x in idxs])
        elif name == "yell":
            cmd_yell(self.gs, self.rng, self.cards_db)
        elif name == "attempt":
            cmd_attempt(self.gs, self.cards_db)
        elif name == "ack":
            cmd_ack(self.gs)
        elif name == "activate_to_green":
            cmd_activate_to_green(self.gs, self.cards_db, str(payload.get("pos", "")))
        elif name == "resolve_pending":
            cmd_resolve_pending(self.gs, self.cards_db, int(payload.get("idx", -1)), str(payload.get("choice", "")))
        elif name == "next":
            idxs = payload.get("indices", [])
            if not isinstance(idxs, list):
                idxs = []
            cmd_next(self.gs, self.rng, self.cards_db, [int(x) for x in idxs])
        elif name == "end_turn":
            cmd_end_turn(self.gs, self.rng)
        elif name == "undo":
            do_undo(self.gs, self.rng)
        elif name == "toggle_debug":
            self.gs.debug = not self.gs.debug
            self.gs.log.append(f"[DEBUG] debug={self.gs.debug}")
        elif name == "peek":
            n = _safe_int(payload.get("n", 5), 5)
            if not self.gs.debug:
                self.gs.log.append("[PEEK] enable debug first")
            else:
                top = self.gs.deck[:max(0, n)]
                self.gs.log.append("[PEEK] top: " + ", ".join(top))
        else:
            self.gs.log.append(f"[ERR] unknown cmd: {name}")

        self.save_trace()
        return self.state_json()


class Handler(BaseHTTPRequestHandler):
    app: App = None  # type: ignore

    def _send(self, code: int, content: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/":
            self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")
            return
        if u.path == "/playmat":
            # Serve playmat.jpg from loveca root (next to scripts) if present.
            candidates = []
            try:
                here = Path(__file__).resolve()
                candidates.append(here.parents[1] / "playmat.jpg")  # loveca/playmat.jpg
            except Exception:
                pass
            candidates.append(Path.cwd() / "playmat.jpg")
            for p in candidates:
                if p and p.exists():
                    self._send(200, p.read_bytes(), "image/jpeg")
                    return
            self._send(404, b"", "text/plain; charset=utf-8")
            return

        if u.path == "/state":
            data = json.dumps(self.app.state_json(), ensure_ascii=False).encode("utf-8")
            self._send(200, data, "application/json; charset=utf-8")
            return
        if u.path == "/img":
            qs = parse_qs(u.query)
            cn = unquote((qs.get("cn", [""])[0] or "").strip())
            p = self.app.img.find(cn)
            if p and p.exists():
                ctype = "image/png"
                if str(p).lower().endswith(".jpg") or str(p).lower().endswith(".jpeg"):
                    ctype = "image/jpeg"
                self._send(200, p.read_bytes(), ctype)
            else:
                self._send(404, b"", "text/plain")
            return
        self._send(404, b"not found", "text/plain; charset=utf-8")

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/cmd":
            self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        n = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(n) if n > 0 else b"{}"
        try:
            obj = json.loads(body.decode("utf-8"))
        except Exception:
            obj = {}
        cmd = str(obj.get("cmd", "")).strip()
        payload = obj.get("payload", {}) or {}
        if not isinstance(payload, dict):
            payload = {}
        out = self.app.cmd(cmd, payload)
        data = json.dumps(out, ensure_ascii=False).encode("utf-8")
        self._send(200, data, "application/json; charset=utf-8")

