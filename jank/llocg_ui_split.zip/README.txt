Install / overwrite (from your project folder, e.g. ~/Desktop/gsim/loveca):

  unzip -o ~/Downloads/llocg_ui_split.zip -d .
  python3 -m py_compile llocg_ui_web.py

Run:
  python3 llocg_ui_web.py --root ./llocg_db_out_full --compiled ./llocg_db_out_full/cards_compiled_v7b.json --code 1RCBL --port 8000

Notes:
- --root should point to the DB output folder (llocg_db_out_full).
- The code now imports helpers from ./llocg_ui/ (db.py, images.py).
