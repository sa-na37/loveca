# -*- coding: utf-8 -*-
"""Card DB utilities for LLCG web UI.

Design notes
- We key cards by *normalized* cardnumber (canonical), but also add several
  lookup variants to tolerate decklist noise (suffix '-', swapped PR position, etc.).
- The web UI treats --root as the DB output folder (llocg_db_out_full).
  Expected defaults under root:
    - cards_compiled_v*.json  (compiled)
    - cards_min_tokv1.json    (tokv1)

This module is intentionally dependency-free (stdlib only).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


# ----------------------------
# Small helpers
# ----------------------------

def _safe_int(x: Any, default: int = 0) -> int:
    try:
        if x is None:
            return default
        if isinstance(x, bool):
            return int(x)
        if isinstance(x, (int,)):
            return int(x)
        s = str(x).strip()
        if s == "":
            return default
        return int(float(s))
    except Exception:
        return default


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


# ----------------------------
# Parsing helpers used in UI
# ----------------------------

def _hearts_from_counts_json(counts_json: str) -> Dict[str, int]:
    """Parse counts JSON like {"pink":2,"any":7} into dict."""
    if not counts_json:
        return {}
    try:
        obj = json.loads(counts_json)
        if isinstance(obj, dict):
            out: Dict[str, int] = {}
            for k, v in obj.items():
                out[str(k)] = _safe_int(v, 0)
            return out
    except Exception:
        pass
    return {}


def _parse_tags_json(s: str) -> List[str]:
    if not s:
        return []
    try:
        obj = json.loads(s)
        if isinstance(obj, list):
            return [str(x) for x in obj]
    except Exception:
        pass
    # fallback: split by comma
    return [t.strip() for t in str(s).split(",") if t.strip()]


def _count_draw_icons(tags_json: str) -> int:
    # tokv1 sometimes stores icons in tags_json; compiled may not.
    tags = _parse_tags_json(tags_json)
    n = 0
    for t in tags:
        if "ドロー" in t or "draw" in t.lower():
            # handle draw, draw+2, etc.
            m = re.search(r"(\d+)", t)
            n += int(m.group(1)) if m else 1
    return n


# ----------------------------
# Type normalization / predicates
# ----------------------------

def _norm_type(s: str) -> str:
    s = (s or "").strip().upper()
    # canonicalize common Japanese labels
    if s in ("メンバー", "MEMBER"):
        return "MEMBER"
    if s in ("ライブ", "LIVE"):
        return "LIVE"
    if s in ("エネルギー", "ENERGY"):
        return "ENERGY"
    # some datasets use "MEMBER_CARD" etc.
    if "MEMBER" in s:
        return "MEMBER"
    if "LIVE" in s:
        return "LIVE"
    if "ENERGY" in s:
        return "ENERGY"
    return s


def is_member_type(card_type_norm: str) -> bool:
    return _norm_type(card_type_norm) == "MEMBER"


def is_live_type(card_type_norm: str) -> bool:
    return _norm_type(card_type_norm) == "LIVE"


# ----------------------------
# Card number normalization
# ----------------------------

def _norm_cardno_for_filename(cn: str) -> str:
    """Normalize for filename resolution.

    Our image folder uses filenames like:
      <folder>/<cardnumber>.png
    where cardnumber is usually exactly the official identifier.
    For some PR cards, the image uses a different ordering:
      PL!HS-PR-018  <->  PL!HS-018-PR
    This function does *not* decide which variant is correct; it
    only cleans obvious noise such as trailing '-'.
    """
    s = (cn or "").strip()
    # strip trailing hyphens (common decklist noise)
    s = re.sub(r"-+$", "", s)
    return s


def _canon_cardno(cn: str) -> str:
    """Canonical lookup key for DB."""
    return _norm_cardno_for_filename(cn)


def _cardno_variants(cn: str) -> List[str]:
    """Generate tolerant variants for lookup.

    Examples:
      PL!HS-PR-018 -> [PL!HS-PR-018, PL!HS-018-PR, PL!HS-PR-018-, PL!HS-018-PR-]

    NOTE: We always include the raw form after trimming whitespace.
    """
    raw = (cn or "").strip()
    base = _canon_cardno(raw)
    vars_: List[str] = []

    def _add(x: str) -> None:
        x = (x or "").strip()
        if x and x not in vars_:
            vars_.append(x)

    _add(raw)
    _add(base)

    # PR swap pattern: PL!HS-PR-018 <-> PL!HS-018-PR
    m = re.match(r"^(PL![^-]+)-PR-(\d+)$", base)
    if m:
        _add(f"{m.group(1)}-{m.group(2)}-PR")

    m2 = re.match(r"^(PL![^-]+)-(\d+)-PR$", base)
    if m2:
        _add(f"{m2.group(1)}-PR-{m2.group(2)}")

    # tolerate trailing '-' variants
    if not base.endswith("-"):
        _add(base + "-")
    for v in list(vars_):
        if not v.endswith("-"):
            _add(v + "-")

    return vars_


# ----------------------------
# Card representation
# ----------------------------

# For image fetching we often filter by these rarity tokens.
# (A) Member side: MEMBER: N R R2 P P2 SEC AR RM PR SD
# (B) Live side:   LIVE:   L L2 SECL SD PR
RARITY_TOKENS = {
    "MEMBER": ["N", "R", "R2", "P", "P2", "SEC", "AR", "RM", "PR", "SD"],
    "LIVE": ["L", "L2", "SECL", "SD", "PR"],
}


@dataclass
class CardInfo:
    cardnumber: str
    cardname: str = ""
    type: str = ""  # normalized type: MEMBER/LIVE/ENERGY
    rarity: str = ""

    # Stats (best-effort; may be missing for some cards)
    cost: int = 0
    blade: int = 0

    # Hearts in tokv1
    base_hearts_counts_json: str = ""  # JSON dict
    required_hearts_counts_json: str = ""  # JSON dict

    # Tags/icons
    tags_json: str = ""  # JSON list


def _get_card(cards_db: Dict[str, CardInfo], cn: str) -> Optional[CardInfo]:
    for key in _cardno_variants(cn):
        ci = cards_db.get(key)
        if ci is not None:
            return ci
    return None


# ----------------------------
# Loaders
# ----------------------------

def load_tokv1_json(path: Path) -> Dict[str, CardInfo]:
    """Load minimal tokv1 json (cards_min_tokv1.json)."""
    data = _read_json(path)
    out: Dict[str, CardInfo] = {}

    # tokv1 format: list of dict
    if isinstance(data, dict) and "cards" in data and isinstance(data["cards"], list):
        rows = data["cards"]
    else:
        rows = data

    if not isinstance(rows, list):
        return out

    for row in rows:
        if not isinstance(row, dict):
            continue
        cn_raw = str(row.get("cardnumber") or row.get("card_no") or row.get("cardnumber_norm") or "").strip()
        if not cn_raw:
            continue
        cn = _canon_cardno(cn_raw)
        ctype = _norm_type(str(row.get("card_type_norm") or row.get("card_type") or row.get("card_type_raw") or ""))
        ci = CardInfo(
            cardnumber=cn,
            cardname=str(row.get("cardname") or ""),
            type=ctype,
            rarity=str(row.get("rarity") or row.get("rarity_norm") or ""),
            cost=_safe_int(row.get("cost"), 0),
            blade=_safe_int(row.get("blade"), 0),
            base_hearts_counts_json=str(row.get("base_hearts_counts_json") or ""),
            required_hearts_counts_json=str(row.get("required_hearts_counts_json") or ""),
            tags_json=str(row.get("tags_json") or row.get("icons_json") or ""),
        )
        # register under variants for robust lookup
        for k in _cardno_variants(cn_raw):
            out[_canon_cardno(k)] = ci
            out[k] = ci

    return out


def load_compiled_json(path: Path) -> Dict[str, CardInfo]:
    """Load compiled json (cards_compiled_v*.json)."""
    data = _read_json(path)
    out: Dict[str, CardInfo] = {}

    # compiled format: list of dict
    rows = data.get("cards") if isinstance(data, dict) else data
    if not isinstance(rows, list):
        return out

    for row in rows:
        if not isinstance(row, dict):
            continue
        cn_raw = str(row.get("cardnumber") or row.get("card_no") or "").strip()
        if not cn_raw:
            continue
        cn = _canon_cardno(cn_raw)
        ctype = _norm_type(str(row.get("card_type") or row.get("type") or ""))

        # compiled may include cost/blade under various names
        cost = _safe_int(row.get("cost"), 0)
        blade = _safe_int(row.get("blade"), 0)
        # sometimes stats are embedded elsewhere; keep minimal

        ci = CardInfo(
            cardnumber=cn,
            cardname=str(row.get("cardname") or row.get("name") or ""),
            type=ctype,
            rarity=str(row.get("rarity") or ""),
            cost=cost,
            blade=blade,
            base_hearts_counts_json=str(row.get("base_hearts_counts_json") or ""),
            required_hearts_counts_json=str(row.get("required_hearts_counts_json") or ""),
            tags_json=str(row.get("tags_json") or ""),
        )

        for k in _cardno_variants(cn_raw):
            out[_canon_cardno(k)] = ci
            out[k] = ci

    return out


def _pick_latest_by_mtime(paths: List[Path]) -> Optional[Path]:
    if not paths:
        return None
    return max(paths, key=lambda p: p.stat().st_mtime)


def load_cards_min(root: Path) -> Dict[str, CardInfo]:
    """Load tokv1 and/or compiled from defaults under root.

    This is the legacy fallback used by older UI versions.
    Prefer load_cards_db() which merges compiled+tokv1.
    """
    out: Dict[str, CardInfo] = {}

    tokv1 = root / "cards_min_tokv1.json"
    if tokv1.exists():
        out.update(load_tokv1_json(tokv1))

    # If no tokv1, try compiled latest
    if not out:
        cands = sorted(root.glob("cards_compiled_v*.json"))
        pick = _pick_latest_by_mtime(cands)
        if pick and pick.exists():
            out.update(load_compiled_json(pick))

    return out


def load_cards_db(root: Path, compiled_path: Optional[Path] = None, tokv1_path: Optional[Path] = None) -> Dict[str, CardInfo]:
    """Merge compiled + tokv1.

    Precedence:
      - Start with compiled (card_type tends to be reliable)
      - Fill missing fields from tokv1 (especially type_norm, hearts)

    Args:
      root: db_out_full folder
      compiled_path: explicit compiled json path; if None, choose latest cards_compiled_v*.json
      tokv1_path: explicit tokv1 path; if None, use root/cards_min_tokv1.json if exists
    """
    db: Dict[str, CardInfo] = {}

    # pick compiled
    if compiled_path is None:
        cands = sorted(root.glob("cards_compiled_v*.json"))
        compiled_path = _pick_latest_by_mtime(cands)

    if compiled_path and Path(compiled_path).exists():
        db.update(load_compiled_json(Path(compiled_path)))

    # fill from tokv1
    if tokv1_path is None:
        p = root / "cards_min_tokv1.json"
        tokv1_path = p if p.exists() else None

    if tokv1_path and Path(tokv1_path).exists():
        tok = load_tokv1_json(Path(tokv1_path))
        for key, tci in tok.items():
            if key not in db:
                db[key] = tci
                continue
            c = db[key]
            # fill only if empty on compiled
            if not c.cardname and tci.cardname:
                c.cardname = tci.cardname
            if not c.type and tci.type:
                c.type = tci.type
            if not c.rarity and tci.rarity:
                c.rarity = tci.rarity
            if c.cost == 0 and tci.cost:
                c.cost = tci.cost
            if c.blade == 0 and tci.blade:
                c.blade = tci.blade
            if not c.base_hearts_counts_json and tci.base_hearts_counts_json:
                c.base_hearts_counts_json = tci.base_hearts_counts_json
            if not c.required_hearts_counts_json and tci.required_hearts_counts_json:
                c.required_hearts_counts_json = tci.required_hearts_counts_json
            if not c.tags_json and tci.tags_json:
                c.tags_json = tci.tags_json

    # if still empty, fallback
    if not db:
        db.update(load_cards_min(root))

    return db
