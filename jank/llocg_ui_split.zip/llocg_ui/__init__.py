"""LLCG minimal local UI package.

This package exists to keep the web UI codebase maintainable.
- db.py    : card DB loading / normalization / type detection
- images.py: image path resolution under <root>/card_images

Run the UI from the project root:
  python3 llocg_ui_web.py --root ./llocg_db_out_full --code <CODE> --port 8000
"""
