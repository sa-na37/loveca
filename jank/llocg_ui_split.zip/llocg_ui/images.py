# -*- coding: utf-8 -*-
"""Image resolution under <root>/card_images.

The image downloader writes files under:
  <root>/card_images/<FOLDER>/<CARDNUMBER>.png

This resolver tolerates:
- cardnumber variants (suffix '-', swapped PR tokens)
- filenames that use "...-PR" vs "...PR-" as seen in some sources

No network I/O is performed here.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from .db import _cardno_variants, _norm_cardno_for_filename


@dataclass
class ImageLocator:
    root: Path

    def __post_init__(self) -> None:
        self.img_root = Path(self.root) / "card_images"

    def _find_existing(self, folder: str, fname: str) -> Optional[Path]:
        p = self.img_root / folder / fname
        if p.exists():
            return p
        return None

    def find(self, cardnumber: str) -> Optional[Path]:
        """Return local image path if exists, else None."""
        cn = str(cardnumber or "").strip()
        if not cn:
            return None

        cands = _cardno_variants(cn)
        # folder is inferred from the set token: BP03 / PB01 / PR / SD etc.
        # Heuristic: take the last token that looks like BP03/PB01 or PR/SD.
        for cand in cands:
            norm = _norm_cardno_for_filename(cand)
            folder = _guess_folder(norm)
            if not folder:
                continue
            # common naming: <norm>.png
            p = self._find_existing(folder, f"{norm}.png")
            if p:
                return p
        return None


def _guess_folder(norm_cardno: str) -> str:
    # examples:
    #   PL!-bp3-025  -> BP03
    #   PL!HS-018-PR -> PR
    #   PL!SP-sd1-019-> SD
    s = norm_cardno
    # explicit PR suffix/prefix
    if "-PR" in s or "PR-" in s:
        return "PR"
    if "-SD" in s or "SD-" in s or "-sd" in s.lower():
        return "SD"
    m = None
    # BPxx
    import re
    m = re.search(r"-bp(\d)-", s, flags=re.IGNORECASE)
    if m:
        return f"BP0{m.group(1)}"
    # PBxx
    m = re.search(r"-pb(\d)-", s, flags=re.IGNORECASE)
    if m:
        return f"PB0{m.group(1)}"
    # fallback by token
    if "-hs-" in s.lower():
        return "PR"  # Hasunosora promos are under PR
    if "-sp-" in s.lower():
        # SP products can still be PB/SD/PR; leave unknown
        pass
    return ""
