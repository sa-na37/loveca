#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
llocg_ui_web.py (manual web UI)
- Resolve zone overlay + ACK -> green room
- Undo, Debug, Peek
- Robust MEMBER/LIVE type check against DB variants
- Phase exists (for UI stability); rules-accurate phase machine can be added later.
"""

import argparse
import csv
import json
import random
import time
import re
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote


# NOTE: DB / card-number normalization / type detection / stats loading live in llocg_ui/db.py
#       Image path resolution lives in llocg_ui/images.py

from llocg_ui.db import (
    CardInfo,
    RARITY_TOKENS,
    _safe_int,
    _read_json,
    _write_text,
    _hearts_from_counts_json,
    _parse_tags_json,
    _count_draw_icons,
    _norm_type,
    is_member_type,
    is_live_type,
    _norm_cardno_for_filename,
    _canon_cardno,
    _cardno_variants,
    _get_card,
    load_cards_db,
    load_cards_min,
)
from llocg_ui.images import ImageLocator

# ----------------------------
# Game state
# ----------------------------

@dataclass
class StageSlot:
    cardnumber: str
    active: bool = True
    temp_blade: int = 0
    temp_until: str = ""  # e.g., end_of_live


@dataclass
class GameState:
    root: str
    code: str
    seed: int
    debug: bool = False

    # Phase exists for UI/trace stability.
    # We'll keep it coarse until rules-accurate phase machine is implemented.
    phase: str = "MAIN"

    deck: List[str] = field(default_factory=list)
    hand: List[str] = field(default_factory=list)

    energy_active: int = 3
    energy_wait: int = 0

    stage: Dict[str, Optional[StageSlot]] = field(default_factory=lambda: {"L": None, "C": None, "R": None})
    green_room: List[str] = field(default_factory=list)
    set_zone: List[str] = field(default_factory=list)
    resolve_zone: List[str] = field(default_factory=list)

    pending: List[Dict[str, Any]] = field(default_factory=list)
    live_start_prompted: bool = False

    turn: int = 1
    log: List[str] = field(default_factory=list)
    undo_stack: List[Dict[str, Any]] = field(default_factory=list)


def snapshot_state(gs: GameState) -> Dict[str, Any]:
    """Create an undo snapshot.

    IMPORTANT: Do NOT include gs.undo_stack itself in the snapshot.
    Including it causes recursive growth (snapshot contains past snapshots),
    which quickly becomes exponential and kills performance.
    We also exclude the text log (gs.log) to keep snapshots small; undo will
    append a new log entry instead of restoring prior logs.
    """
    stage_snap: Dict[str, Any] = {}
    for k in ("L", "C", "R"):
        slot = gs.stage.get(k)
        if slot is None:
            stage_snap[k] = None
        else:
            stage_snap[k] = {"cardnumber": slot.cardnumber, "active": bool(slot.active), "temp_blade": int(getattr(slot, "temp_blade", 0) or 0), "temp_until": str(getattr(slot, "temp_until", "") or "")}

    return {
        "phase": gs.phase,
        "deck": list(gs.deck),
        "hand": list(gs.hand),
        "energy_active": int(gs.energy_active),
        "energy_wait": int(gs.energy_wait),
        "stage": stage_snap,
        "green_room": list(gs.green_room),
        "set_zone": list(gs.set_zone),
        "resolve_zone": list(gs.resolve_zone),
        "pending": json.loads(json.dumps(gs.pending)) if gs.pending else [],
        "live_start_prompted": bool(gs.live_start_prompted),
        "turn": int(gs.turn),
    }


def restore_state(gs: GameState, snap: Dict[str, Any]) -> None:
    """Restore from an undo snapshot (see snapshot_state)."""
    gs.phase = snap.get("phase", gs.phase)
    gs.deck = list(snap.get("deck", gs.deck))
    gs.hand = list(snap.get("hand", gs.hand))
    gs.energy_active = int(snap.get("energy_active", gs.energy_active))
    gs.energy_wait = int(snap.get("energy_wait", gs.energy_wait))

    stage_in = snap.get("stage", {}) or {}
    stage_new: Dict[str, Optional[StageSlot]] = {"L": None, "C": None, "R": None}
    for k in ("L", "C", "R"):
        v = stage_in.get(k)
        if v is None:
            stage_new[k] = None
        else:
            stage_new[k] = StageSlot(cardnumber=str(v.get("cardnumber", "")), active=bool(v.get("active", True)), temp_blade=_safe_int(v.get("temp_blade", 0), 0), temp_until=str(v.get("temp_until", "") or ""))
    gs.stage = stage_new

    gs.green_room = list(snap.get("green_room", gs.green_room))
    gs.set_zone = list(snap.get("set_zone", gs.set_zone))
    gs.resolve_zone = list(snap.get("resolve_zone", gs.resolve_zone))
    gs.pending = list(snap.get("pending", gs.pending) or [])
    gs.live_start_prompted = bool(snap.get("live_start_prompted", gs.live_start_prompted))
    gs.turn = int(snap.get("turn", gs.turn))



def _trace_path(root: Path) -> Path:
    # Human-readable trace for this UI session (overwritten on new game).
    return root / "sim_trace.txt"


def trace_write(gs: GameState, msg: str) -> None:
    # Keep in-memory log + file trace.
    ts = time.strftime("%H:%M:%S")
    line = f"{ts} {msg}"
    gs.log.append(line)
    try:
        p = _trace_path(Path(gs.root))
        with p.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        # Never break gameplay due to trace I/O.
        pass


def begin_turn(gs: GameState) -> None:
    # Rules order (coarse): ACTIVE -> ENERGY -> DRAW -> MAIN
    gs.phase = "ACTIVE"
    refresh(gs)
    trace_write(gs, f"[PHASE] ACTIVE (refresh) E active={gs.energy_active} wait={gs.energy_wait}")
    gs.phase = "ENERGY"
    energy_phase(gs)
    trace_write(gs, f"[PHASE] ENERGY (+1) E active={gs.energy_active} wait={gs.energy_wait}")
    gs.phase = "DRAW"
    d = draw(gs, 1)
    trace_write(gs, f"[PHASE] DRAW (draw {d}) hand={len(gs.hand)} deck={len(gs.deck)}")
    gs.phase = "MAIN"
    trace_write(gs, f"[PHASE] MAIN turn={gs.turn}")


def push_undo(gs: GameState, rng: random.Random) -> None:
    gs.undo_stack.append({"snap": snapshot_state(gs), "rng": rng.getstate()})


def do_undo(gs: GameState, rng: random.Random) -> bool:
    if not gs.undo_stack:
        trace_write(gs, "[UNDO] nothing to undo")
        return False
    last = gs.undo_stack.pop()
    restore_state(gs, last["snap"])
    rng.setstate(last["rng"])
    trace_write(gs, "[UNDO] restored previous state")
    return True


def load_simdeck(root: Path, code: str) -> List[str]:
    p = root / "sim_decks" / f"deck_{code}.json"
    obj = _read_json(p)
    cards: List[str] = []
    for ent in obj.get("cards", []) or []:
        if not isinstance(ent, dict):
            continue
        cnt = _safe_int(ent.get("count", 0), 0)
        cn = _canon_cardno(str(ent.get("db_id") or ent.get("cardnumber") or ent.get("card_no") or ent.get("tsv_card_no") or ""))
        if cn and cnt > 0:
            cards.extend([cn] * cnt)
    return cards


def new_game(root: Path, code: str, seed: int, debug: bool) -> Tuple[GameState, random.Random]:
    deck_cards = load_simdeck(root, code)
    rng = random.Random(seed)
    rng.shuffle(deck_cards)

    gs = GameState(root=str(root), code=code, seed=seed, debug=debug, phase="ACTIVE")
    gs.deck = deck_cards
    for _ in range(6):
        if gs.deck:
            gs.hand.append(gs.deck.pop(0))

    # Reset trace file for this UI session
    try:
        _trace_path(root).write_text("", encoding="utf-8")
    except Exception:
        pass

    trace_write(gs, f"[NEW] code={code} seed={seed} opening_hand=6 turn={gs.turn}")

    # Start turn 1 (ACTIVE→ENERGY→DRAW→MAIN) so energy/draw are applied at game start.
    begin_turn(gs)

    return gs, rng


def draw(gs: GameState, n: int) -> int:
    k = 0
    for _ in range(n):
        if not gs.deck:
            break
        gs.hand.append(gs.deck.pop(0))
        k += 1
    return k


def pay_energy(gs: GameState, cost: int) -> bool:
    if cost <= 0:
        return True
    if gs.energy_active < cost:
        return False
    gs.energy_active -= cost
    gs.energy_wait += cost
    return True


def refresh(gs: GameState) -> None:
    for k in ("L", "C", "R"):
        if gs.stage.get(k):
            gs.stage[k].active = True
    gs.energy_active += gs.energy_wait
    gs.energy_wait = 0


def energy_phase(gs: GameState) -> None:
    gs.energy_active += 1


def stage_blade(gs: GameState, cards_db: Dict[str, CardInfo]) -> int:
    s = 0
    for slot in gs.stage.values():
        if not slot or not slot.active:
            continue
        c = _get_card(cards_db, slot.cardnumber)
        s += (int(c.blade) if c else 0) + int(getattr(slot, "temp_blade", 0) or 0)
    return s


def owned_base_hearts(gs: GameState, cards_db: Dict[str, CardInfo]) -> Dict[str, int]:
    pool: Dict[str, int] = {}
    for slot in gs.stage.values():
        if not slot:
            continue
        c = _get_card(cards_db, slot.cardnumber)
        if not c:
            continue
        for k, v in (c.base_hearts or {}).items():
            pool[k] = pool.get(k, 0) + int(v)
    return pool


def cheer_hearts_from_resolve(gs: GameState, cards_db: Dict[str, CardInfo]) -> Dict[str, int]:
    pool: Dict[str, int] = {}
    for cn in gs.resolve_zone:
        c = _get_card(cards_db, cn)
        if not c:
            continue
        for k, v in (c.blade_hearts or {}).items():
            pool[k] = pool.get(k, 0) + int(v)
    return pool


def can_satisfy_req(req: Dict[str, int], owned: Dict[str, int]) -> Tuple[bool, Dict[str, Any]]:
    pool = {k: int(v) for k, v in (owned or {}).items()}
    for k in ("red", "green", "blue", "all"):
        pool.setdefault(k, 0)

    alloc = {"use_red": 0, "use_green": 0, "use_blue": 0, "use_all": 0}

    for color, key in (("red", "use_red"), ("green", "use_green"), ("blue", "use_blue")):
        need = int(req.get(color, 0) or 0)
        take = min(pool[color], need)
        alloc[key] += take
        need -= take
        if need > 0:
            if pool["all"] < need:
                return (False, {"reason": f"lack {color} and ALL", "need": need, "pool_all": pool["all"]})
            alloc["use_all"] += need
            pool["all"] -= need

    need_all = int(req.get("all", 0) or 0)
    if need_all > 0:
        if pool["all"] < need_all:
            return (False, {"reason": "lack ALL", "need_all": need_all, "pool_all": pool["all"]})
        alloc["use_all"] += need_all
        pool["all"] -= need_all

    need_any = int(req.get("any", 0) or 0)
    if need_any > 0:
        total = pool["red"] + pool["green"] + pool["blue"] + pool["all"]
        if total < need_any:
            return (False, {"reason": "lack total hearts", "need_any": need_any, "pool_total": total})
        for k in sorted(("red", "green", "blue", "all"), key=lambda kk: pool[kk], reverse=True):
            if need_any <= 0:
                break
            take = min(pool[k], need_any)
            pool[k] -= take
            need_any -= take
            if k == "red":
                alloc["use_red"] += take
            elif k == "green":
                alloc["use_green"] += take
            elif k == "blue":
                alloc["use_blue"] += take
            else:
                alloc["use_all"] += take

    return (True, alloc)



def _count_blade_icons(text: str) -> int:
    t = text or ""
    n = t.count("<(ブレード)>")
    if n > 0:
        return n
    if "ブレードを一本" in t or "ブレードを1本" in t:
        return 1
    if "ブレードを二本" in t or "ブレードを2本" in t:
        return 2
    return 0


def _has_sacrifice_ability(ci: Optional[CardInfo]) -> bool:
    if not ci or not ci.abilities:
        return False
    for ab in ci.abilities:
        if not isinstance(ab, dict):
            continue
        at = str(ab.get("ability_type", "") or "")
        if "起動" not in at:
            continue
        clauses = ab.get("clauses", [])
        if not isinstance(clauses, list):
            continue
        for cl in clauses:
            if not isinstance(cl, dict):
                continue
            raw = str(cl.get("raw", "") or "")
            eff = str(cl.get("effect_template", "") or raw)
            if ("控え室" in eff) and ("置く" in eff) and ("このメンバー" in eff or "このメンバー" in raw):
                return True
    return False


def _enqueue_live_start_prompts(gs: GameState, cards_db: Dict[str, CardInfo]) -> int:
    """Queue live-start prompts once per live (until Attempt resolves)."""
    if gs.live_start_prompted:
        return 0
    prompts: List[Dict[str, Any]] = []
    for pos in ("L", "C", "R"):
        slot = gs.stage.get(pos)
        if not slot or not slot.active:
            continue
        ci = _get_card(cards_db, slot.cardnumber)
        if not ci or not ci.abilities:
            continue
        for ab in ci.abilities:
            if not isinstance(ab, dict):
                continue
            trig = str(ab.get("trigger", "") or "")
            if "ライブ開始時" not in trig:
                continue
            clauses = ab.get("clauses", [])
            if not isinstance(clauses, list):
                continue
            for cl in clauses:
                if not isinstance(cl, dict):
                    continue
                raw = str(cl.get("raw", "") or "")
                cost = str(cl.get("cost_template", "") or raw)
                eff = str(cl.get("effect_template", "") or raw)
                if "<(E)>" not in cost and "[E]" not in cost and "Ｅ" not in cost and "E" not in cost:
                    continue
                blades = _count_blade_icons(eff)
                if blades <= 0:
                    continue
                prompts.append({
                    "kind": "live_start_blade",
                    "pos": pos,
                    "cn": ci.cardnumber,
                    "need_e": 1,
                    "blades": int(blades),
                    "text": f"{pos}: {ci.cardnumber} ライブ開始時 [E]1 → ブレード+{blades} (ライブ終了時まで)",
                })
    if prompts:
        gs.pending.extend(prompts)
        gs.live_start_prompted = True
        gs.log.append(f"[PROMPT] live-start abilities queued: {len(prompts)}")
    return len(prompts)


def _clear_end_of_live_buffs(gs: GameState) -> None:
    for pos in ("L", "C", "R"):
        slot = gs.stage.get(pos)
        if not slot:
            continue
        if getattr(slot, "temp_until", "") == "end_of_live":
            slot.temp_blade = 0
            slot.temp_until = ""

def cmd_play(gs: GameState, cards_db: Dict[str, CardInfo], hand_idx: int, pos: str) -> None:
    pos = pos.upper()
    if pos not in ("L", "C", "R"):
        gs.log.append("[ERR] play: pos must be L/C/R")
        return
    if hand_idx < 0 or hand_idx >= len(gs.hand):
        gs.log.append("[ERR] play: invalid hand index")
        return
    existing = gs.stage.get(pos)
    baton_old_cn = None
    baton_old_cost = 0
    if existing is not None:
        # Baton touch (ルール 9.6.2.3.2): you may put your member in that area into green room to reduce the cost.
        baton_old_cn = existing.cardnumber
        old = _get_card(cards_db, baton_old_cn)
        baton_old_cost = int(old.cost) if old else 0

    cn = gs.hand[hand_idx]
    c = _get_card(cards_db, cn)
    ctype = (c.type if c else "")
    if not c or not is_member_type(ctype):
        gs.log.append(f"[ERR] play: not a MEMBER card: cn={cn} db_type='{ctype}'")
        return

    cost = int(c.cost or 0)
    pay_cost = cost
    if baton_old_cn is not None:
        # Always apply baton touch when the target stage area is occupied.
        # Reduce the cost by the replaced member's cost (min 0), and send the replaced member to green room.
        pay_cost = max(0, cost - int(baton_old_cost or 0))
        gs.green_room.append(baton_old_cn)
        gs.log.append(f"[BATON] {pos}: {baton_old_cn} -> green room; reduce {cost} by {baton_old_cost} => pay {pay_cost}")

    if not pay_energy(gs, pay_cost):
        gs.log.append(f"[ERR] play: insufficient energy (need {pay_cost}, have {gs.energy_active})")
        return

    gs.hand.pop(hand_idx)
    gs.stage[pos] = StageSlot(cardnumber=(c.cardnumber if c else cn), active=True)
    gs.log.append(f"[PLAY] {pos} <- {cn} (pay {pay_cost}; E active={gs.energy_active} wait={gs.energy_wait})")


def cmd_set(gs: GameState, rng: random.Random, indices: List[int]) -> None:
    if len(indices) > 3:
        gs.log.append("[ERR] set: max 3 cards")
        return
    if any(i < 0 or i >= len(gs.hand) for i in indices):
        gs.log.append("[ERR] set: invalid indices")
        return
    idxs = sorted(set(indices), reverse=True)
    picked = []
    for i in idxs:
        picked.append(gs.hand.pop(i))
    picked.reverse()
    gs.set_zone = picked[:]
    drawn = draw(gs, len(picked))
    gs.log.append(f"[SET] set {len(picked)} cards, drew {drawn}")


def cmd_yell(gs: GameState, rng: random.Random, cards_db: Dict[str, CardInfo]) -> None:
    n = stage_blade(gs, cards_db)
    if n <= 0:
        gs.log.append("[YELL] 0 (no blade on active stage members)")
        return
    revealed = []
    for _ in range(n):
        if not gs.deck:
            break
        revealed.append(gs.deck.pop(0))
    gs.resolve_zone.extend(revealed)

    draw_n = 0
    for cn in revealed:
        c = _get_card(cards_db, cn)
        if c:
            draw_n += _count_draw_icons(c.blade_heart_tags_json)
    got = draw(gs, draw_n) if draw_n > 0 else 0
    gs.log.append(f"[YELL] revealed {len(revealed)} (blade={n}), draw+{draw_n} -> drew {got}")


def cmd_attempt(gs: GameState, cards_db: Dict[str, CardInfo]) -> None:
    if not gs.set_zone:
        gs.log.append("[ATTEMPT] no set cards")
        return

    if gs.pending:
        gs.log.append("[WARN] attempt: pending prompts exist; resolve them first.")
        return

    if _enqueue_live_start_prompts(gs, cards_db) > 0:
        gs.log.append("[INFO] attempt: resolve live-start prompts, then click Attempt again.")
        return

    lives = []
    nonlives = []
    for cn in gs.set_zone:
        c = _get_card(cards_db, cn)
        if c and is_live_type(c.type):
            lives.append(cn)
        else:
            nonlives.append(cn)

    if nonlives:
        gs.green_room.extend(nonlives)

    base = owned_base_hearts(gs, cards_db)
    cheer = cheer_hearts_from_resolve(gs, cards_db)
    owned = dict(base)
    for k, v in cheer.items():
        owned[k] = owned.get(k, 0) + int(v)

    ok_all = True
    gs.log.append(f"[ATTEMPT] LIVE={len(lives)} base={base} cheer={cheer} owned={owned}")
    for cn in lives:
        c = _get_card(cards_db, cn)
        req = (c.required_hearts if c else {}) or {}
        ok, alloc = can_satisfy_req(req, owned)
        ok_all = ok_all and ok
        gs.log.append(f"  live: {'OK' if ok else 'NG'} {cn} req={req} alloc={alloc}")

    if lives:
        gs.green_room.extend(lives)

    gs.set_zone = []
    gs.log.append(f"[ATTEMPT] result={'SUCCESS' if ok_all else 'FAIL'}")

    _clear_end_of_live_buffs(gs)
    gs.live_start_prompted = False


def cmd_ack(gs: GameState) -> None:
    if not gs.resolve_zone:
        gs.log.append("[ACK] resolve zone empty")
        return
    n = len(gs.resolve_zone)
    gs.green_room.extend(gs.resolve_zone)
    gs.resolve_zone = []
    gs.log.append(f"[ACK] moved {n} revealed cards -> green room")



def cmd_activate_to_green(gs: GameState, cards_db: Dict[str, CardInfo], pos: str) -> None:
    pos = str(pos or "").upper()
    if pos not in ("L", "C", "R"):
        gs.log.append("[ERR] activate: pos must be L/C/R")
        return
    slot = gs.stage.get(pos)
    if not slot:
        gs.log.append(f"[ERR] activate: empty stage {pos}")
        return
    ci = _get_card(cards_db, slot.cardnumber)
    if not ci:
        gs.log.append(f"[ERR] activate: card not in DB: {slot.cardnumber}")
        return
    if not _has_sacrifice_ability(ci):
        gs.log.append(f"[ERR] activate: no supported 'to green room' ability on {ci.cardnumber}")
        return
    gs.green_room.append(slot.cardnumber)
    gs.stage[pos] = None
    gs.log.append(f"[ACT] {pos}: {ci.cardnumber} -> green room")


def cmd_resolve_pending(gs: GameState, cards_db: Dict[str, CardInfo], idx: int, choice: str) -> None:
    if idx < 0 or idx >= len(gs.pending):
        gs.log.append("[ERR] resolve_pending: invalid idx")
        return
    p = gs.pending.pop(idx)
    kind = str(p.get("kind", "") or "")
    choice = str(choice or "").lower()
    if kind == "live_start_blade":
        pos = str(p.get("pos", "") or "").upper()
        need_e = _safe_int(p.get("need_e", 1), 1)
        blades = _safe_int(p.get("blades", 0), 0)
        slot = gs.stage.get(pos)
        if not slot:
            gs.log.append(f"[SKIP] prompt: stage {pos} empty (ignored)")
            return
        if choice in ("pay", "yes", "y", "1", "true"):
            if not pay_energy(gs, need_e):
                gs.log.append(f"[ERR] ability: insufficient energy for [E]{need_e} (have {gs.energy_active})")
                return
            slot.temp_blade += blades
            slot.temp_until = "end_of_live"
            gs.log.append(f"[AUTO] {pos}: paid [E]{need_e} -> temp blade +{blades} (until end of live)")
        else:
            gs.log.append(f"[SKIP] {pos}: live-start blade ability skipped")
    else:
        gs.log.append(f"[WARN] resolve_pending: unknown kind='{kind}' (ignored)")

def cmd_end_turn(gs: GameState, rng: random.Random) -> None:

    if gs.set_zone:
        trace_write(gs, "[WARN] end_turn: set_zone not empty; please ATTEMPT before ending.")
        return
    if gs.resolve_zone:
        trace_write(gs, "[WARN] end_turn: resolve_zone not empty; please ACK before ending.")
        return
    if gs.pending:
        trace_write(gs, "[WARN] end_turn: pending prompts exist; resolve them before ending.")
        return


    gs.turn += 1
    trace_write(gs, f"[TURN] -> {gs.turn} (start)")
    begin_turn(gs)


HTML = r"""<!doctype html><html><head><meta charset="utf-8"/>
<title>LLCG Manual UI</title>
<style>
body{font-family:system-ui,sans-serif;margin:0}
.wrap{display:grid;grid-template-columns:1fr 380px;height:100vh}
.main{padding:10px;overflow:auto;background:#f7f7f7}
.side{border-left:1px solid #ddd;padding:10px;overflow:auto;background:#fff}
.row{display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap}
.panel{background:#fff;border:1px solid #ddd;border-radius:8px;padding:10px}
.title{font-weight:600;margin-bottom:6px}
.cards{display:flex;gap:6px;flex-wrap:wrap}
.card{width:110px}
.card img{width:90px;border-radius:6px;border:1px solid #ccc}
.card .cap{font-size:12px;line-height:1.2;margin-top:4px}
.stageSlot{width:120px;height:160px;border:2px dashed #aaa;border-radius:10px;display:flex;align-items:center;justify-content:center;background:#fafafa}
.stack{display:flex;align-items:flex-start;gap:0;overflow-x:auto;overflow-y:hidden;padding:4px 4px 10px 4px;min-height:160px}
.stack img{width:120px;position:relative;left:auto;top:auto;border-radius:6px;border:1px solid #ccc;box-shadow:0 1px 2px rgba(0,0,0,.12)}
.stack img + img{margin-left:-80px}
.btn{padding:6px 10px;border:1px solid #999;background:#fff;border-radius:6px;cursor:pointer}
.log{font-family:ui-monospace,Menlo,monospace;font-size:12px;white-space:pre-wrap}
.small{font-size:12px;color:#444}
.kbd{font-family:ui-monospace,monospace;background:#eee;padding:1px 6px;border-radius:6px;border:1px solid #ddd}
</style></head><body>
<div class="wrap">
<div class="main">
  <div class="row">
    <div class="panel" style="min-width:420px;">
      <div class="title">Stage</div>
      <div class="row">
        <div class="stageSlot" id="slotL" onclick="slotClick('L')">L</div>
        <div class="stageSlot" id="slotC" onclick="slotClick('C')">C</div>
        <div class="stageSlot" id="slotR" onclick="slotClick('R')">R</div>
      </div>
      <div class="small">Click a hand card → click L/C/R to play.</div>
    </div>

    <div class="panel">
      <div class="title">Resolve Zone (解決領域) / ACK → Green Room (控室)</div>
      <div class="stack" id="resolveStack"></div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="sendCmd('yell', {})">Yell (エール)</button>
        <button class="btn" onclick="sendCmd('ack', {})">ACK (確認→控室)</button>
        <button class="btn" onclick="sendCmd('undo', {})">Undo</button>
      </div>
    </div>

    <div class="panel">
      <div class="title">Set Zone (伏せ)</div>
      <div class="cards" id="setZone"></div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="setSelected()">Set selected (max3)</button>
        <button class="btn" onclick="sendCmd('attempt', {})">Attempt LIVE</button>
        <button class="btn" onclick="sendCmd('end_turn', {})">End Turn</button>
      </div>
    </div>
  </div>

  <div class="panel" style="margin-top:10px;">
    <div class="title">Hand</div>
    <div class="cards" id="hand"></div>
    <div class="small">Selected: <span class="kbd" id="selInfo">none</span></div>
  </div>
</div>

<div class="side">
  <div class="panel">
    <div class="title">Status</div>
    <div class="small" id="statusLine"></div>
    <div class="small" id="countsLine"></div>
    <div class="panel" style="margin-top:10px;">
      <div class="title">Selected Stage</div>
      <div class="small" id="selStageInfo">(click a stage slot)</div>
      <div id="selStageActions" class="row" style="margin-top:8px;"></div>
    </div>
    <div class="panel" style="margin-top:10px;">
      <div class="title">Pending Prompts</div>
      <div class="small" id="pendingBox">(none)</div>
    </div>
    <div class="row" style="margin-top:8px;">
      <button class="btn" onclick="sendCmd('toggle_debug', {})">Toggle Debug</button>
      <button class="btn" onclick="sendCmd('peek', {n:5})">Peek 5</button>
    </div>
  </div>

  <div class="panel" style="margin-top:10px;">
    <div class="title">Log</div>
    <div class="log" id="log"></div>
  </div>
</div>
</div>

<script>
let STATE=null;
let selectedHand=new Set();
let playPick=null;
let selectedStage=null;

function escapeHtml(s){return (s||"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
function imgUrl(cn){return "/img?cn="+encodeURIComponent(cn);}

async function fetchState(){
  const r=await fetch("/state");
  STATE=await r.json();
  render();
}

function renderCard(cn, cap){
  const div=document.createElement("div");
  div.className="card";
  const img=document.createElement("img");
  img.src=imgUrl(cn);
  img.onerror=()=>{img.style.display="none";};
  div.appendChild(img);
  const p=document.createElement("div");
  p.className="cap";
  p.innerHTML=escapeHtml(cap);
  div.appendChild(p);
  return div;
}

function render(){
  if(!STATE) return;
  document.getElementById("statusLine").innerText =
    `Turn ${STATE.turn} | Phase=${STATE.phase} | Energy active=${STATE.energy_active} wait=${STATE.energy_wait} | Debug=${STATE.debug}`;
  document.getElementById("countsLine").innerText =
    `Deck=${STATE.deck.length} Hand=${STATE.hand.length} GreenRoom=${STATE.green_room.length} Resolve=${STATE.resolve_zone.length}`;

  ["L","C","R"].forEach(pos=>{
    const el=document.getElementById("slot"+pos);
    el.innerHTML="";
    el.style.outline = (selectedStage===pos ? "3px solid #333" : "none");
    const slot=STATE.stage[pos];
    if(slot && slot.cardnumber){
      const img=document.createElement("img");
      img.src=imgUrl(slot.cardnumber);
      img.style.width="110px";
      img.style.borderRadius="6px";
      img.style.border="1px solid #ccc";
      el.appendChild(img);
    }else{
      el.innerText=pos;
    }
  });

  
  // Selected stage + actions
  const selInfo=document.getElementById("selStageInfo");
  const selActions=document.getElementById("selStageActions");
  selActions.innerHTML="";
  if(!selectedStage){
    selInfo.innerText="(click a stage slot)";
  }else{
    const slot=STATE.stage[selectedStage];
    if(!slot || !slot.cardnumber){
      selInfo.innerText=`${selectedStage}: (empty)`;
    }else{
      const det=(STATE.stage_detail||{})[selectedStage]||{};
      selInfo.innerText=`${selectedStage}: ${det.cardnumber||slot.cardnumber}  ${det.name||""}  [${det.type||""}]`;
      if(det.has_sac){
        const b=document.createElement("button");
        b.className="btn";
        b.innerText="起動：このメンバーを控え室に置く";
        b.onclick=()=>sendCmd("activate_to_green",{pos:selectedStage});
        selActions.appendChild(b);
      }
    }
  }

  // Pending prompts
  const pb=document.getElementById("pendingBox");
  const pend=STATE.pending||[];
  if(!pend.length){
    pb.innerText="(none)";
  }else{
    pb.innerHTML="";
    pend.forEach((p,idx)=>{
      const row=document.createElement("div");
      row.className="row";
      row.style.gap="6px";
      const t=document.createElement("div");
      t.className="small";
      t.style.flex="1";
      t.innerText=p.text||JSON.stringify(p);
      const yes=document.createElement("button");
      yes.className="btn";
      yes.innerText="Pay";
      yes.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"pay"});
      const no=document.createElement("button");
      no.className="btn";
      no.innerText="Skip";
      no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
      row.appendChild(t); row.appendChild(yes); row.appendChild(no);
      pb.appendChild(row);
    });
  }

const rs=document.getElementById("resolveStack");
  rs.innerHTML="";
  const rz=STATE.resolve_zone||[];
  const show=rz.slice(Math.max(0, rz.length-12));
  show.forEach((cn,i)=>{
    const img=document.createElement("img");
    img.src=imgUrl(cn);
    img.style.left=(i*6)+"px";
    img.style.top=(i*4)+"px";
    rs.appendChild(img);
  });

  const sz=document.getElementById("setZone");
  sz.innerHTML="";
  (STATE.set_zone||[]).forEach(cn=>{ sz.appendChild(renderCard(cn, cn)); });

  const hand=document.getElementById("hand");
  hand.innerHTML="";
  (STATE.hand||[]).forEach((cn, idx)=>{
    const div=renderCard(cn, `${idx}: ${cn}`);
    if(selectedHand.has(idx)) div.style.outline="3px solid #333";
    div.style.cursor="pointer";
    div.onclick=()=>{
      if(selectedHand.has(idx)) selectedHand.delete(idx);
      else selectedHand.add(idx);
      playPick=idx;
      document.getElementById("selInfo").innerText = Array.from(selectedHand).sort((a,b)=>a-b).join(", ");
      render();
    };
    hand.appendChild(div);
  });

  document.getElementById("log").innerText=(STATE.log||[]).slice(-120).join("\n");
}

function slotClick(pos){
  if(playPick===null){
    selectedStage = (selectedStage===pos ? null : pos);
    render();
    return;
  }
  sendCmd("play",{hand_idx:playPick,pos:pos});
  playPick=null;
  selectedHand.clear();
}

function setSelected(){
  const idxs=Array.from(selectedHand).sort((a,b)=>a-b).slice(0,3);
  sendCmd("set",{indices:idxs});
  selectedHand.clear();
  playPick=null;
}

async function sendCmd(cmd,payload){
  const body={cmd:cmd,payload:payload||{}};
  const r=await fetch("/cmd",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  STATE=await r.json();
  render();
}

fetchState();
</script>
</body></html>
"""


class App:
    def __init__(self, root: Path, code: str, seed: int, debug: bool, compiled: Optional[Path] = None, tokv1: Optional[Path] = None):
        self.root = root
        self.outdir = root / "sim_out"
        self.cards_db = load_cards_db(root, compiled_path=compiled, tokv1_path=tokv1)
        self.img = ImageLocator(root)
        self.gs, self.rng = new_game(root, code, seed=seed, debug=debug)
        self.save_trace()

    def save_trace(self):
        self.outdir.mkdir(parents=True, exist_ok=True)
        _write_text(self.outdir / "ui_trace.txt", "\n".join(self.gs.log) + ("\n" if self.gs.log else ""))

    def state_json(self) -> Dict[str, Any]:
        return {
            "root": self.gs.root,
            "code": self.gs.code,
            "seed": self.gs.seed,
            "debug": self.gs.debug,
            "turn": self.gs.turn,
            "phase": self.gs.phase,
            "deck": self.gs.deck if self.gs.debug else ["?"] * len(self.gs.deck),
            "hand": self.gs.hand,
            "energy_active": self.gs.energy_active,
            "energy_wait": self.gs.energy_wait,
            "stage": {k: (asdict(v) if v else None) for k, v in self.gs.stage.items()},
            "green_room": self.gs.green_room,
            "set_zone": self.gs.set_zone,
            "resolve_zone": self.gs.resolve_zone,
            "pending": self.gs.pending,
            "stage_detail": {k: ({
                "cardnumber": v.cardnumber,
                "name": (_get_card(self.cards_db, v.cardnumber).name if _get_card(self.cards_db, v.cardnumber) else ""),
                "type": (_get_card(self.cards_db, v.cardnumber).type if _get_card(self.cards_db, v.cardnumber) else ""),
                "has_sac": _has_sacrifice_ability(_get_card(self.cards_db, v.cardnumber)),
            } if v else None) for k, v in self.gs.stage.items()},
            "log": self.gs.log,
        }

    def cmd(self, name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        mutating = name in {"play", "set", "yell", "attempt", "ack", "end_turn", "toggle_debug", "activate_to_green", "resolve_pending"}
        if mutating and name != "toggle_debug":
            push_undo(self.gs, self.rng)

        if name == "play":
            cmd_play(self.gs, self.cards_db, int(payload.get("hand_idx", -1)), str(payload.get("pos", "")))
        elif name == "set":
            idxs = payload.get("indices", [])
            if not isinstance(idxs, list):
                idxs = []
            cmd_set(self.gs, self.rng, [int(x) for x in idxs])
        elif name == "yell":
            cmd_yell(self.gs, self.rng, self.cards_db)
        elif name == "attempt":
            cmd_attempt(self.gs, self.cards_db)
        elif name == "ack":
            cmd_ack(self.gs)
        elif name == "activate_to_green":
            cmd_activate_to_green(self.gs, self.cards_db, str(payload.get("pos", "")))
        elif name == "resolve_pending":
            cmd_resolve_pending(self.gs, self.cards_db, int(payload.get("idx", -1)), str(payload.get("choice", "")))
        elif name == "end_turn":
            cmd_end_turn(self.gs, self.rng)
        elif name == "undo":
            do_undo(self.gs, self.rng)
        elif name == "toggle_debug":
            self.gs.debug = not self.gs.debug
            self.gs.log.append(f"[DEBUG] debug={self.gs.debug}")
        elif name == "peek":
            n = _safe_int(payload.get("n", 5), 5)
            if not self.gs.debug:
                self.gs.log.append("[PEEK] enable debug first")
            else:
                top = self.gs.deck[:max(0, n)]
                self.gs.log.append("[PEEK] top: " + ", ".join(top))
        else:
            self.gs.log.append(f"[ERR] unknown cmd: {name}")

        self.save_trace()
        return self.state_json()


class Handler(BaseHTTPRequestHandler):
    app: App = None  # type: ignore

    def _send(self, code: int, content: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/":
            self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")
            return
        if u.path == "/state":
            data = json.dumps(self.app.state_json(), ensure_ascii=False).encode("utf-8")
            self._send(200, data, "application/json; charset=utf-8")
            return
        if u.path == "/img":
            qs = parse_qs(u.query)
            cn = unquote((qs.get("cn", [""])[0] or "").strip())
            p = self.app.img.find(cn)
            if p and p.exists():
                self._send(200, p.read_bytes(), "image/png")
            else:
                self._send(404, b"", "text/plain")
            return
        self._send(404, b"not found", "text/plain; charset=utf-8")

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/cmd":
            self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        n = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(n) if n > 0 else b"{}"
        try:
            obj = json.loads(body.decode("utf-8"))
        except Exception:
            obj = {}
        cmd = str(obj.get("cmd", "")).strip()
        payload = obj.get("payload", {}) or {}
        if not isinstance(payload, dict):
            payload = {}
        out = self.app.cmd(cmd, payload)
        data = json.dumps(out, ensure_ascii=False).encode("utf-8")
        self._send(200, data, "application/json; charset=utf-8")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--code", required=True)
    ap.add_argument("--compiled", default=None, help="path to cards_compiled_*.json (optional)")
    ap.add_argument("--tokv1", default=None, help="path to cards_min_tokv1.csv/json (optional)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()

    root = Path(args.root).resolve()
    compiled_p = Path(args.compiled).resolve() if args.compiled else None
    tokv1_p = Path(args.tokv1).resolve() if args.tokv1 else None
    app = App(root=root, code=args.code, seed=int(args.seed), debug=bool(args.debug), compiled=compiled_p, tokv1=tokv1_p)

    Handler.app = app
    server = ThreadingHTTPServer(("127.0.0.1", int(args.port)), Handler)
    print(f"[UI] root={root}")
    print(f"[UI] code={args.code} seed={args.seed} debug={args.debug}")
    print(f"[UI] open: http://127.0.0.1:{args.port}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[UI] bye")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
