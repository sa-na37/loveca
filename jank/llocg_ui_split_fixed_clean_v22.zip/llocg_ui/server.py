# -*- coding: utf-8 -*-
from __future__ import annotations

"""llocg_ui.server

HTTP サーバ（/ , /state, /cmd, /img）とフロントHTML。

- `App` が状態（GameState/RNG/DB/ImageLocator）を保持
- `Handler` は stdlib の http.server でルーティング
"""

import json
from dataclasses import asdict

APP_VERSION = "v15"
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.parse import urlparse, parse_qs, unquote

from .db import load_cards_db
from .images import ImageLocator
from .engine import (
    GameState,
    new_game,
    push_undo, do_undo,
    cmd_play, cmd_set, cmd_yell, cmd_attempt, cmd_ack,
    cmd_end_turn, cmd_next,
    cmd_activate_to_green,
    cmd_resolve_pending,
    trace_write,
    _get_card, _has_sacrifice_ability,
)

def _write_text(path, text, encoding="utf-8"):
    """Write text to path, creating parent dirs."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding=encoding)


HTML = r"""<!doctype html><html><head><meta charset="utf-8"/>
<title>LLCG Manual UI v15</title>
<style>
body{font-family:system-ui,sans-serif;margin:0}
.wrap{display:grid;grid-template-columns:1fr 380px;height:100vh}
.main{padding:10px;overflow:auto;background:#f7f7f7}
.side{border-left:1px solid #ddd;padding:10px;overflow:auto;background:#fff}
.row{display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap}
.panel{background:#fff;border:1px solid #ddd;border-radius:8px;padding:10px}
.title{font-weight:600;margin-bottom:6px}
.cards{display:flex;gap:6px;flex-wrap:wrap}

/* Card rendering (MEMBER upright, LIVE rotated).
   Baseline size is aligned to the stage slot (~110px wide).
   Keep captions outside the media box so they never get clipped. */
.card{width:130px}
.media{width:110px;height:154px;position:relative;display:flex;align-items:center;justify-content:center}
.media img{width:100%;height:100%;border-radius:6px;border:1px solid #ccc;object-fit:contain;display:block;background:#fff}
.card .cap{font-size:12px;line-height:1.2;margin-top:4px}

/* LIVE: portrait box; rotate the landscape image inside, centered */
.liveBox{width:110px;height:158px;position:relative;overflow:hidden;border-radius:6px}
.liveBox .rotWrap{position:absolute;top:50%;left:50%;width:158px;height:110px;transform:translate(-50%,-50%) rotate(90deg);transform-origin:center;display:flex;align-items:center;justify-content:center}
.liveBox .rotWrap img{width:100%;height:100%;object-fit:contain;border:none;border-radius:0;background:transparent}

/* Stage slots */
.stageSlot{width:120px;height:160px;border:2px dashed #aaa;border-radius:10px;display:flex;align-items:center;justify-content:center;background:#fafafa}

/* Resolve stack */
.stack{display:flex;align-items:flex-start;gap:0;overflow-x:auto;overflow-y:hidden;padding:4px 4px 10px 4px;min-height:190px}
.stack .card{width:auto}
.stack .media{width:110px;height:154px}
/* ~2/3 overlap (show ~1/3 of next) */
.stack .card + .card{margin-left:-75px}
.stack .card{position:relative}

/* Buttons */
.btn{padding:6px 10px;border:1px solid #999;background:#fff;border-radius:6px;cursor:pointer}
.matWrap{position:relative;width:100%;max-width:1100px;aspect-ratio:1560/851;border:1px solid #ddd;border-radius:10px;overflow:hidden;background:#222;margin-bottom:10px}
.matImg{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:contain;object-position:center;opacity:1}
.zone{position:absolute;border:2px dashed rgba(255,255,255,0.35);border-radius:10px;pointer-events:none}
.zoneInner{position:absolute;inset:0;display:flex;gap:6px;align-items:center;justify-content:flex-start;flex-wrap:nowrap;overflow:hidden;padding:6px;pointer-events:auto}
.zoneInner .card img{width:100%;height:100%}
.zoneTitle{position:absolute;left:6px;top:6px;font-size:12px;color:#fff;background:rgba(0,0,0,.55);padding:2px 6px;border-radius:6px}
.matLog{position:absolute;left:1.2%;top:60.5%;width:16.6%;height:36.8%;background:rgba(255,255,255,.78);border:1px solid rgba(0,0,0,.15);border-radius:12px;overflow:auto;padding:10px;z-index:6;box-shadow:0 8px 30px rgba(0,0,0,.12)}
.matLog pre{margin:0;font-size:11px;line-height:1.25;white-space:pre-wrap;word-break:break-word}
.matLog .matLogTitle{font-weight:700;font-size:12px;margin:0 0 6px 0;opacity:.8}

.matOverlay{position:absolute;left:0;top:0;right:0;bottom:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.12);z-index:9}
.matOverlayPanel{background:rgba(255,255,255,.92);border:1px solid rgba(0,0,0,.12);border-radius:18px;box-shadow:0 20px 60px rgba(0,0,0,.18);padding:14px 14px 12px 14px;max-width:75%;min-width:420px}
.matOverlayHeader{display:flex;align-items:center;gap:10px;margin-bottom:10px}
.matOverlayBadge{background:rgba(0,0,0,.70);color:#fff;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:700}
.matOverlayText{font-size:14px;font-weight:700;opacity:.9}
.matOverlayChoices{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.matOverlayChoices select{font-size:14px;padding:6px 8px;border-radius:10px;border:1px solid rgba(0,0,0,.2)}
.matOverlayChoices button{font-size:14px;padding:6px 10px;border-radius:10px;border:1px solid rgba(0,0,0,.25);background:#fff;cursor:pointer}

.matResolveLabel{position:absolute;left:10px;top:10px;background:rgba(0,0,0,.70);color:#fff;border-radius:999px;padding:4px 10px;font-size:12px;font-weight:700;z-index:2}
.deckBadge{position:absolute;right:6px;bottom:6px;font-size:12px;color:#fff;background:rgba(0,0,0,.65);padding:2px 6px;border-radius:6px}
.clickSlot{width:120px;height:160px;border:2px dashed rgba(255,255,255,0.55);border-radius:10px;display:flex;align-items:center;justify-content:center;color:#fff;background:rgba(0,0,0,0.15);pointer-events:auto;cursor:pointer}
.matStageSlot{width:120px;height:160px;display:flex;align-items:center;justify-content:center;border:2px dashed rgba(120,120,120,0.55);border-radius:12px;background:rgba(255,255,255,0.15);cursor:pointer;pointer-events:auto;}
.matStageSlot:hover{background:rgba(255,255,255,0.22);}
.matStageSlot.sel{outline:3px solid rgba(0,0,0,0.35);outline-offset:2px;}
.matStageSlot .card{position:relative}

.log{font-family:ui-monospace,Menlo,monospace;font-size:12px;white-space:pre-wrap}
.small{font-size:12px;color:#444}
.kbd{font-family:ui-monospace,monospace;background:#eee;padding:1px 6px;border-radius:6px;border:1px solid #ddd}


/* LIVE rotation is handled by .liveBox/.rotWrap (see above). */

/* Playmat: use the same baseline size as the main UI (aligned to stage slot).
   This avoids the "small cards" regression and keeps LIVE rotation consistent. */
.zoneInner .card{width:auto}
.zoneInner .media{width:110px;height:154px}
.zoneInner .liveBox{width:110px;height:158px}
.zoneInner .liveBox .rotWrap{width:158px;height:110px}
.zoneInner .media img{border-radius:6px}

/* Set zone panel: fixed height, horizontal scroll so Next button doesn't move */
#setZone{flex-wrap:nowrap;overflow-x:auto;overflow-y:hidden;height:190px;align-items:flex-start}
#setZone .card{flex:0 0 auto}

/* Playmat: rotated live cards inside mat zones (smaller) */

/* Cheer/reveal stack on playmat */
.stackRow{display:flex;align-items:center;justify-content:flex-start;flex-wrap:nowrap;overflow:hidden}
.stackRow .card{flex:0 0 auto}
.stackRow .card + .card{margin-left:-36px}

/* Playmat hand: overlap-to-fit + hover bring-to-front */
.zoneInner.handLayout{position:relative;overflow:hidden}
.zoneInner.handLayout .card{position:absolute;top:6px;left:0;transition:transform 80ms ease}
.zoneInner.handLayout .card:hover{transform:translateY(-3px)}

/* Playmat resolve overlay: appears only when resolve has cards */
.resolveOverlay{position:absolute;left:22%;top:46%;width:56%;height:30%;background:rgba(255,255,255,0.90);border:2px solid rgba(0,0,0,0.08);border-radius:14px;box-shadow:0 10px 24px rgba(0,0,0,0.08);padding:10px;z-index:30;}
.resolveOverlay .overlayLabel{position:absolute;left:10px;top:8px;background:rgba(0,0,0,.65);color:#fff;padding:4px 10px;border-radius:10px;font-size:13px;z-index:31}
.pendingBox{position:absolute;left:22%;top:33%;width:56%;background:rgba(255,255,255,0.92);border:2px solid rgba(0,0,0,0.08);border-radius:14px;box-shadow:0 10px 24px rgba(0,0,0,0.10);padding:12px 12px 10px 12px;z-index:35;display:none}
.pendingBox .pendingTitle{font-weight:800;font-size:16px;margin:0 0 8px 0}
.pendingBox .pendingText{font-size:13px;color:#222;margin:0 0 10px 0;white-space:pre-wrap}
.pendingBox .pendingRow{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.pendingBox select{padding:6px 8px;border-radius:8px;border:1px solid #bbb;background:#fff}
.pendingBox .btn{padding:8px 12px;border:1px solid #999;border-radius:10px;background:#fff;cursor:pointer}
.pendingBox .btn.primary{background:#111;color:#fff;border-color:#111}
.resolveOverlay .zoneInner{height:calc(100% - 26px);overflow:hidden}

/* Live-set zone on playmat: landscape box base (110x154 -> 154x110) */
.liveSetBox{width:154px;height:110px;position:relative;overflow:hidden;border-radius:6px;background:#fff}
.liveSetBox img{width:100%;height:100%;object-fit:contain;border-radius:6px}
.liveSetBox .rotWrapCCW{position:absolute;top:50%;left:50%;width:110px;height:154px;transform:translate(-50%,-50%) rotate(-90deg);transform-origin:center;}
.liveSetBox .rotWrapCCW img{width:100%;height:100%;object-fit:contain;border-radius:6px}


</style></head><body>
<div class="wrap">
<div class="main">
<div class="panel" style="width:100%;">
  <div class="title">Playmat</div>
  <div class="matWrap" id="matWrap">
    <img class="matImg" src="/playmat" alt="playmat"/>
    <div id="matLog" class="matLog" style="display:none;">
      <div class="matLogTitle" style="font-weight:700;margin-bottom:6px;">Log</div>
      <pre id="matLogBody" style="white-space:pre-wrap;word-break:break-word;font-size:11px;line-height:1.25;"></pre>
    </div>
    <!-- zones (approx; adjust later) -->
    <div class="zone" id="zLive" style="left:19.2%;top:2.4%;width:60.6%;height:25.0%;">
      <div class="zoneTitle">Live set</div>
      <div class="zoneInner" id="matSet"></div>
    </div>
    <div class="zone" id="zStage" style="left:19.2%;top:28.6%;width:60.6%;height:33.2%;">
      <div class="zoneTitle">Stage</div>
      <div class="zoneInner" id="matStage" style="justify-content:space-around;">
        <div class="matStageSlot" id="matStageL"></div>
        <div class="matStageSlot" id="matStageC"></div>
        <div class="matStageSlot" id="matStageR"></div>
      </div>
    </div>
    <div class="zone" id="zHand" style="left:19.2%;top:63.0%;width:60.6%;height:34.6%;">
      <div class="zoneTitle">Hand</div>
      <div class="zoneInner handLayout" id="matHand"></div>

      <div class="matCmdBar" id="matCmdBar">
        <button class="btn" id="btnUndo">Undo</button>
        <button class="btn" id="btnNext">Next</button>
      </div>
    </div>
    <div class="zone" id="zDeck" style="left:80.4%;top:2.4%;width:18.8%;height:28.0%;">
      <div class="zoneTitle">Deck</div>
      <div class="zoneInner" id="matDeck" style="justify-content:center;"></div>
      <div class="deckBadge" id="matDeckCount"></div>
    </div>

    <div class="zone" id="zReveal" style="left:1.2%;top:29.0%;width:16.8%;height:33.0%;">
      <div class="zoneInner stackRow" id="matReveal"></div>
    </div>
    <div class="zone" id="zGreen" style="left:80.4%;top:34.2%;width:18.8%;height:33.0%;">
      <div class="zoneTitle">Waiting room</div>
      <div class="zoneInner" id="matGreen" style="justify-content:center;"></div>
      <div class="deckBadge" id="matGreenCount"></div>
    </div>

    <div id="matResolveOverlay" class="resolveOverlay" style="display:none;">
      <div class="overlayLabel">Cheer / Resolve</div>
      <div class="zoneInner stackRow" id="matResolve"></div>
    </div>

    <div id="matPendingOverlay" class="resolveOverlay" style="display:none;">
      <div class="overlayLabel">Auto choice</div>
      <div style="padding-top:26px;">
        <div id="matPendingText" class="small" style="font-size:12px;margin-bottom:8px;"></div>
        <div id="matPendingChoices"></div>
      </div>
    </div>
    </div>
  </div>
  <div class="small">※ 枠位置は暫定（playmat基準で後で微調整）。左の成功ライブ置き場は背景位置で実質カットしています。</div>
</div>

  <div class="row">
    <div class="panel" style="min-width:420px;">
      <div class="title">Stage</div>
      <div class="row">
        <div class="stageSlot" id="slotL" onclick="slotClick('L')">L</div>
        <div class="stageSlot" id="slotC" onclick="slotClick('C')">C</div>
        <div class="stageSlot" id="slotR" onclick="slotClick('R')">R</div>
      </div>
      <div class="small">Click a hand card → click L/C/R to play.</div>
    </div>

    <div class="panel">
      <div class="title">Resolve Zone (解決領域) / ACK → Green Room (控室)</div>
      <div class="stack" id="resolveStack"></div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="sendCmd('yell', {})">Yell (エール)</button>
        <button class="btn" onclick="sendCmd('ack', {})">ACK (確認→控室)</button>
        <button class="btn" onclick="sendCmd('undo', {})">Undo</button>
      </div>
    </div>

    <div class="panel">
      <div class="title">Set Zone (伏せ)</div>
      <div class="cards" id="setZone"></div>
      <div class="row" style="margin-top:8px;">
        <button class="btn" onclick="setSelected()">Set selected (max3)</button>
        <button class="btn" onclick="sendCmd('attempt', {})">Attempt LIVE</button>
        <button class="btn" onclick="sendCmd('end_turn', {})">End Turn</button>
        <button class="btn" onclick="nextStep()">Next</button>
      </div>
    </div>
  </div>

  <div class="panel" style="margin-top:10px;">
    <div class="title">Hand</div>
    <div class="cards" id="hand"></div>
    <div class="small">Selected: <span class="kbd" id="selInfo">none</span></div>
  </div>
</div>

<div class="side">
  <div class="panel">
    <div class="title">Status</div>
    <div class="small" id="statusLine"></div>
    <div class="small" id="countsLine"></div>
    <div class="panel" style="margin-top:10px;">
      <div class="title">Selected Stage</div>
      <div class="small" id="selStageInfo">(click a stage slot)</div>
      <div id="selStageActions" class="row" style="margin-top:8px;"></div>
    </div>
    <div class="panel" style="margin-top:10px;">
      <div class="title">Pending Prompts</div>
      <div class="small" id="pendingBox">(none)</div>
    </div>
    <div class="row" style="margin-top:8px;">
      <button class="btn" onclick="sendCmd('toggle_debug', {})">Toggle Debug</button>
      <button class="btn" onclick="sendCmd('peek', {n:5})">Peek 5</button>
    </div>
  </div>

  <div class="panel" style="margin-top:10px;">
    <div class="title">Log</div>
    <div class="log" id="log"></div>
  </div>
</div>
</div>

<script>
let STATE=null;
let selectedHand=new Set();
let playPick=null;
let selectedStage=null;

function escapeHtml(s){return (s||"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
function imgUrl(cn){return "/img?cn="+encodeURIComponent(cn);}
function labelFor(cn){
  const mLabel=(STATE&&STATE.cn2label)?STATE.cn2label:{};
  const mName=(STATE&&STATE.cn2name)?STATE.cn2name:{};
  return mLabel[cn] || mName[cn] || cn;
}
// State objects sometimes store cards as raw cardnumber strings ("PL!..."),
// and sometimes as objects like {cardnumber, name, ...}. Normalize here.
function cnOf(x){
  if(!x) return "";
  if(typeof x === 'string') return x;
  if(typeof x === 'object'){
    if(x.cardnumber) return x.cardnumber;
    if(x.cn) return x.cn;
  }
  return "";
}
function isLive(cn){
  const t=(STATE&&STATE.cn2type)?(STATE.cn2type[cn]||""): "";
  return (String(t).toUpperCase()==='LIVE');
}

function renderMat(){
  const wrap=document.getElementById("matWrap");
  if(!wrap) return;

  // --- Stage slots ---
  const slots=["L","C","R"];
  slots.forEach(s=>{
    const box=document.getElementById("matStage"+s);
    if(!box) return;
    box.innerHTML="";
    const cn=cnOf((STATE.stage||{})[s]) || "";
    if(cn){
      const d=document.createElement("div");
      d.className="card";
      const media=document.createElement("div");
      media.className="media" + (isLive(cn)?" liveBox":"");
      const img=document.createElement("img");
      img.src=imgUrl(cn);
      img.alt=cn;
      if(isLive(cn)){
        const w=document.createElement("div");
        w.className="rotWrap";
        w.appendChild(img);
        media.appendChild(w);
      }else{
        media.appendChild(img);
      }
      d.appendChild(media);
      box.appendChild(d);
    }else{
      const em=document.createElement('div');
      em.style.fontSize='12px';
      em.style.opacity=0.6;
      em.style.textAlign='center';
      em.style.height='100%';
      em.style.display='flex';
      em.style.alignItems='center';
      em.style.justifyContent='center';
      em.textContent='(empty)';
      box.appendChild(em);
    }

    // click-to-play (playmat-first): select a hand card, then click L/C/R
    box.onclick = () => {
      selectedStage = s;
      if(playPick === null || playPick === undefined){
        render();
        return;
      }
      sendCmd('play', { hand_idx: playPick, pos: s });
    };
  });

  // --- Live set (伏せ) on playmat ---
  const setBox=document.getElementById("matSet");
  if(setBox){
    setBox.innerHTML="";
    const arr=(STATE.set_zone||[]);
    arr.forEach((raw,idx)=>{
      const cn = cnOf(raw);
      const d=document.createElement("div");
      d.className="card";
      d.style.zIndex=String(10+idx);
      const media=document.createElement("div");
      media.className="media liveSetBox";
      const img=document.createElement("img");
      img.src=imgUrl(cn);
      img.alt=cn;
      if(isLive(cn)){
        // LIVE card: keep landscape (no rotation)
        media.appendChild(img);
      }else{
        // Member card: rotate CCW to fit landscape slot
        const w=document.createElement("div");
        w.className="rotWrapCCW";
        w.appendChild(img);
        media.appendChild(w);
      }
      d.appendChild(media);
      setBox.appendChild(d);
    });
    const cnt=document.getElementById("matSetCount");
    if(cnt) cnt.textContent = "x" + String(((STATE.set_zone||[]).length));
  }

  // --- Waiting room / Green room ---
  const greenBox=document.getElementById("matGreen");
  if(greenBox){
    greenBox.innerHTML="";
    const top=cnOf(STATE.green_room_top||"");
    if(top){
      const d=document.createElement("div");
      d.className="card";
      const media=document.createElement("div");
      media.className="media" + (isLive(top)?" liveBox":"");
      const img=document.createElement("img");
      img.src=imgUrl(top);
      img.alt=top;
      if(isLive(top)){
        const w=document.createElement("div");
        w.className="rotWrap";
        w.appendChild(img);
        media.appendChild(w);
      }else{
        media.appendChild(img);
      }
      d.appendChild(media);
      greenBox.appendChild(d);
    }
    const cnt=document.getElementById("matGreenCount");
    if(cnt) cnt.textContent = "x" + String((STATE.green_room_count||0));
  }

  // --- Hand on playmat: overlap to fit, hover to front ---
  const handBox=document.getElementById("matHand");
  if(handBox){
    handBox.innerHTML="";
    (STATE.hand||[]).forEach((raw,idx)=>{
      const cn = cnOf(raw);
      const d=document.createElement("div");
      d.className="card";
      d.style.cursor = 'pointer';
      d.dataset.baseZ=String(10+idx);
      d.style.zIndex=d.dataset.baseZ;
      if(playPick === idx){
        d.style.outline = '3px solid #111';
        d.style.outlineOffset = '2px';
      }
      const media=document.createElement("div");
      media.className="media" + (isLive(cn)?" liveBox":"");
      const img=document.createElement("img");
      img.src=imgUrl(cn);
      img.alt=cn;
      if(isLive(cn)){
        const w=document.createElement("div");
        w.className="rotWrap";
        w.appendChild(img);
        media.appendChild(w);
      }else{
        media.appendChild(img);
      }
      d.appendChild(media);
      d.addEventListener("mouseenter", ()=>{ d.style.zIndex="9999"; });
      d.addEventListener("mouseleave", ()=>{ d.style.zIndex=d.dataset.baseZ || "10"; });
      d.addEventListener('click', ()=>{
        // select from hand on playmat; then click Stage L/C/R to play
        playPick = idx;
        renderAll();
      });
      handBox.appendChild(d);
    });

    // layout
    const cards=[...handBox.children];
    const n=cards.length;
    if(n>0){
      const cardW=110;
      const gap=8;
      const avail=Math.max(0, handBox.clientWidth - 12);
      const step = (n<=1) ? 0 : Math.min(cardW+gap, (avail-cardW)/(n-1));
      cards.forEach((el,i)=>{
        el.style.position="absolute";
        el.style.top="6px";
        el.style.left=(i*step)+"px";
        el.dataset.baseZ=String(10+i);
        el.style.zIndex=el.dataset.baseZ;
      });
      const totalW = (n==1) ? cardW : ( (n-1)*step + cardW );
      handBox.style.minHeight="170px";
      handBox.style.width = "100%";
      // allow some right padding
      handBox.style.overflow="hidden";
    }
  }

  // --- Resolve overlay on playmat (expanded only when needed) ---
  const overlay=document.getElementById("matResolveOverlay");
  const resBox=document.getElementById("matResolve");
  if(overlay && resBox){
    const arr=(STATE.resolve_zone||[]);
    if(!arr.length){
      overlay.style.display="none";
      resBox.innerHTML="";
    }else{
      overlay.style.display="block";
      resBox.innerHTML="";
      arr.forEach((cn,idx)=>{
        const d=document.createElement("div");
        d.className="card";
        d.style.zIndex=String(10+idx);
        const media=document.createElement("div");
        media.className="media" + (isLive(cn)?" liveBox":"");
        const img=document.createElement("img");
        img.src=imgUrl(cn);
        img.alt=cn;
        if(isLive(cn)){
          const w=document.createElement("div");
          w.className="rotWrap";
          w.appendChild(img);
          media.appendChild(w);
        }else{
          media.appendChild(img);
        }
        d.appendChild(media);
        resBox.appendChild(d);
      });
    }
  }

  // --- Pending prompts popup on playmat (only when fired) ---
  const pov = document.getElementById('matPendingOverlay');
  const pText = document.getElementById('matPendingText');
  const pChoices = document.getElementById('matPendingChoices');
  if(pov && pText && pChoices){
    const pend = (STATE.pending || []);
    if(!pend.length){
      pov.style.display='none';
      pText.textContent='';
      pChoices.innerHTML='';
    }else{
      pov.style.display='block';
      const p = pend[0];
      const idx = 0;
      pText.textContent = p.title || p.text || 'Pending';
      pChoices.innerHTML='';

      // options model:
      // - live-start pay/skip: p.options == ['pay','skip']
      // - pick prompts: p.options contains cardnumbers (+ sometimes 'skip')
      // - where p.candidates exists, we treat it as selectable targets
      let opts = (p.options || p.choices || []);
      const cand = (p.candidates || []);
      const labelMap = {
        'pay':'Pay (E1)',
        'skip':'Skip',
        '__SKIP__':'Skip',
        'topdeck':'Top of deck',
        'green_room':'Green Room',
        'hand':'Hand',
      };

      // If the engine says "you may choose fewer", always provide a Skip/Finish button.
      const allowLess = !!p.allow_less;
      const hasSkip = allowLess || (opts||[]).includes('skip') || (opts||[]).includes('__SKIP__');

      // If candidates exist, use select+buttons (Choose / Skip)
      if(cand.length){
        const sel = document.createElement('select');
        sel.style.maxWidth='100%';
        sel.style.padding='6px 8px';
        sel.style.borderRadius='8px';
        sel.style.border='1px solid rgba(0,0,0,.18)';

        // Prefer opts that look like cardnumbers; otherwise fall back to candidates.
        const pickList = (opts && opts.length) ? opts.filter(v => String(v) !== 'skip' && String(v) !== '__SKIP__') : cand;
        pickList.forEach(v=>{
          const o=document.createElement('option');
          o.value=String(v);
          const s=String(v);
          o.textContent = labelMap[s] || labelFor(s);
          sel.appendChild(o);
        });

        const row=document.createElement('div');
        row.style.display='flex';
        row.style.gap='10px';
        row.style.alignItems='center';
        row.style.marginTop='10px';

        const btnChoose = document.createElement('button');
        btnChoose.className='btn';
        btnChoose.textContent='Choose';
        btnChoose.onclick=()=>{
          const choice = sel.value;
          sendCmd('resolve_pending',{idx,choice});
        };

        row.appendChild(sel);
        row.appendChild(btnChoose);

        if(hasSkip){
          const btnSkip = document.createElement('button');
          btnSkip.className='btn';
          btnSkip.textContent='Skip';
          btnSkip.onclick=()=>{
            sendCmd('resolve_pending',{idx,choice:'skip'});
          };
          row.appendChild(btnSkip);
        }
        pChoices.appendChild(row);
      } else {
        // Otherwise: render one button per option (pay/skip etc). If no options, show OK.
        const row=document.createElement('div');
        row.style.display='flex';
        row.style.flexWrap='wrap';
        row.style.gap='10px';
        row.style.alignItems='center';
        row.style.marginTop='10px';

        if(opts && opts.length){
          opts.forEach(v=>{
            const s=String(v);
            const btn = document.createElement('button');
            btn.className='btn';
            btn.textContent = labelMap[s] || labelFor(s);
            btn.onclick = ()=>{ sendCmd('resolve_pending',{idx,choice:s}); };
            row.appendChild(btn);
          });
          if(hasSkip && !opts.includes('skip')){
            const btnSkip = document.createElement('button');
            btnSkip.className='btn';
            btnSkip.textContent='Skip';
            btnSkip.onclick=()=>{ sendCmd('resolve_pending',{idx,choice:'skip'}); };
            row.appendChild(btnSkip);
          }
        }else{
          const btn = document.createElement('button');
          btn.className='btn';
          btn.textContent='OK';
          btn.onclick=()=>{ sendCmd('resolve_pending',{idx,choice:''}); };
          row.appendChild(btn);
        }
        pChoices.appendChild(row);
      }
    }
  }

  // --- Playmat log panel (use empty left area) ---
  const ml = document.getElementById('matLog');
  const mlb = document.getElementById('matLogBody');
  if(ml && mlb){
    const lines = (STATE.log || []);
    if(!lines.length){
      ml.style.display='none';
      mlb.textContent='';
    }else{
      ml.style.display='block';
      const tail = lines.slice(Math.max(0, lines.length-18));
      mlb.textContent = tail.join('\n');
      ml.scrollTop = ml.scrollHeight;
    }
  }

}

async function fetchState(){
  const r=await fetch("/state");
  STATE=await r.json();
  render();
}

function renderCard(cn, cap){
  const div=document.createElement("div");
  div.className = isLive(cn) ? "card liveCard" : "card";

  const media=document.createElement("div");
  media.className = isLive(cn) ? "media liveBox" : "media";

  const img=document.createElement("img");
  img.src=imgUrl(cn);
  img.onerror=()=>{img.style.display="none";};

  if(isLive(cn)){
    const w=document.createElement('div');
    w.className='rotWrap';
    w.appendChild(img);
    media.appendChild(w);
  }else{
    media.appendChild(img);
  }
  div.appendChild(media);

  const p=document.createElement("div");
  p.className="cap";
  p.innerHTML=escapeHtml(cap);
  div.appendChild(p);
  return div;
}

function render(){
  if(!STATE) return;
  document.getElementById("statusLine").innerText =
    `Turn ${STATE.turn} | Phase=${STATE.phase} | Energy active=${STATE.energy_active} wait=${STATE.energy_wait} | Debug=${STATE.debug}`;
  document.getElementById("countsLine").innerText =
    `Deck=${STATE.deck.length} Hand=${STATE.hand.length} GreenRoom=${STATE.green_room.length} Resolve=${STATE.resolve_zone.length} | v20`;

  ["L","C","R"].forEach(pos=>{
    const el=document.getElementById("slot"+pos);
    el.innerHTML="";
    el.style.outline = (selectedStage===pos ? "3px solid #333" : "none");
    const slot=STATE.stage[pos];
    const cn = cnOf(slot);
    if(cn){
      const img=document.createElement("img");
      img.src=imgUrl(cn);
      img.style.width="110px";
      img.style.borderRadius="6px";
      img.style.border="1px solid #ccc";
      el.appendChild(img);
    }else{
      el.innerText=pos;
    }
  });

  
  // Selected stage + actions
  const selInfo=document.getElementById("selStageInfo");
  const selActions=document.getElementById("selStageActions");
  selActions.innerHTML="";
  if(!selectedStage){
    selInfo.innerText="(click a stage slot)";
  }else{
    const slot=STATE.stage[selectedStage];
    if(!slot || !slot.cardnumber){
      selInfo.innerText=`${selectedStage}: (empty)`;
    }else{
      const det=(STATE.stage_detail||{})[selectedStage]||{};
      selInfo.innerText=`${selectedStage}: ${det.cardnumber||slot.cardnumber}  ${det.name||""}  [${det.type||""}]`;
      if(det.has_sac){
        const b=document.createElement("button");
        b.className="btn";
        b.innerText="起動：このメンバーを控え室に置く";
        b.onclick=()=>sendCmd("activate_to_green",{pos:selectedStage});
        selActions.appendChild(b);
      }
    }
  }

  // Pending prompts
  const pb=document.getElementById("pendingBox");
  const pend=STATE.pending||[];
  if(!pend.length){
    pb.innerText="(none)";
  }else{
    pb.innerHTML="";
    pend.forEach((p,idx)=>{
      const row=document.createElement("div");
      row.className="row";
      row.style.gap="6px";
      row.style.alignItems="center";

      const t=document.createElement("div");
      t.className="small";
      t.style.flex="1";
      t.innerText=p.text||JSON.stringify(p);
      row.appendChild(t);

if((p.kind||"")==="choose_shioriko_enter"){
  const sel=document.createElement("select");
  sel.className="btn";
  const op1=document.createElement("option"); op1.value="energy"; op1.innerText="エネルギーを1枚アクティブ";
  const op2=document.createElement("option"); op2.value="topdeck"; op2.innerText="虹ヶ咲LIVEを最大2枚デッキ上";
  sel.appendChild(op1); sel.appendChild(op2);
  row.appendChild(sel);
  const go=document.createElement("button");
  go.className="btn";
  go.innerText="Choose";
  go.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});
  row.appendChild(go);
}else if((p.kind||"")==="topdeck_live_from_green"){
  const sel=document.createElement("select");
  sel.className="btn";
  (p.options||[]).forEach((cn)=>{
    const op=document.createElement("option");
    op.value=cn;
    op.innerText=labelFor(cn);
    sel.appendChild(op);
  });
  row.appendChild(sel);
  const put=document.createElement("button");
  put.className="btn";
  put.innerText="Put";
  put.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});
  const no=document.createElement("button");
  no.className="btn";
  no.innerText="Skip";
  no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
  row.appendChild(put);
  row.appendChild(no);
}else if((p.kind||"")==="shioriko_topdeck_pick1" || (p.kind||"")==="shioriko_topdeck_pick2"){
  const sel=document.createElement("select");
  sel.className="btn";
  (p.options||[]).forEach((cn)=>{
    const op=document.createElement("option");
    op.value=cn;
    op.innerText=labelFor(cn);
    sel.appendChild(op);
  });
  row.appendChild(sel);
  const put=document.createElement("button");
  put.className="btn";
  put.innerText="Topdeck";
  put.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});
  const no=document.createElement("button");
  no.className="btn";
  no.innerText="Skip";
  no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
  row.appendChild(put);
  row.appendChild(no);
}else if((p.kind||"")==="pick_live_from_green"){

        const sel=document.createElement("select");
        sel.className="btn";
        (p.options||[]).forEach((cn)=>{
          const op=document.createElement("option");
          op.value=cn;
          op.innerText=labelFor(cn);
          sel.appendChild(op);
        });
        row.appendChild(sel);

        const take=document.createElement("button");
        take.className="btn";
        take.innerText="Take";
        take.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:(sel.value||"")});

        const no=document.createElement("button");
        no.className="btn";
        no.innerText="Skip";
        no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});

        row.appendChild(take);
        row.appendChild(no);
      }else{
        const yes=document.createElement("button");
        yes.className="btn";
        yes.innerText="Pay";
        yes.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"pay"});
        const no=document.createElement("button");
        no.className="btn";
        no.innerText="Skip";
        no.onclick=()=>sendCmd("resolve_pending",{idx:idx,choice:"skip"});
        row.appendChild(yes);
        row.appendChild(no);
      }

      pb.appendChild(row);
    });
  }

  renderMat();

  const rs=document.getElementById("resolveStack");
  rs.innerHTML="";
  const rz=STATE.resolve_zone||[];
  const show=rz.slice(Math.max(0, rz.length-12));
  
show.forEach((cn, i)=>{
  const d=document.createElement('div');
  d.className = isLive(cn) ? 'card liveCard' : 'card';
  d.style.position = 'relative';
  d.style.zIndex = String(10 + i);

  const media=document.createElement("div");
  media.className = isLive(cn) ? "media liveBox" : "media";

  const img=document.createElement('img');
  img.src=imgUrl(cn);
  img.title=labelFor(cn);

  if(isLive(cn)){
    const w=document.createElement('div');
    w.className='rotWrap';
    w.appendChild(img);
    media.appendChild(w);
  }else{
    media.appendChild(img);
  }
  d.appendChild(media);
  rs.appendChild(d);
});

  const sz=document.getElementById("setZone");
  sz.innerHTML="";
  (STATE.set_zone||[]).forEach(cn=>{ const el=renderCard(cn, labelFor(cn)); sz.appendChild(el); });

  const hand=document.getElementById("hand");
  hand.innerHTML="";
  (STATE.hand||[]).forEach((cn, idx)=>{
    const div=renderCard(cn, `${idx}: ${labelFor(cn)}`);
    if(selectedHand.has(idx)) div.style.outline="3px solid #333";
    div.style.cursor="pointer";
    div.onclick=()=>{
      if(selectedHand.has(idx)) selectedHand.delete(idx);
      else selectedHand.add(idx);
      playPick=idx;
      document.getElementById("selInfo").innerText = Array.from(selectedHand).sort((a,b)=>a-b).join(", ");
      render();
    };
    hand.appendChild(div);
  });

  document.getElementById("log").innerText=(STATE.log||[]).slice(-120).join("\n");
}

function slotClick(pos){
  if(playPick===null){
    selectedStage = (selectedStage===pos ? null : pos);
    render();
    return;
  }
  sendCmd("play",{hand_idx:playPick,pos:pos});
  playPick=null;
  selectedHand.clear();
}

function setSelected(){
  const idxs=Array.from(selectedHand).sort((a,b)=>a-b).slice(0,3);
  sendCmd("set",{indices:idxs});
  selectedHand.clear();
  playPick=null;
}


function nextStep(){
  const idxs=Array.from(selectedHand).sort((a,b)=>a-b).slice(0,3);
  sendCmd("next",{indices:idxs});
  selectedHand.clear();
  playPick=null;
}


async function sendCmd(cmd,payload){
  const body={cmd:cmd,payload:payload||{}};
  const r=await fetch("/cmd",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  STATE=await r.json();
  render();
}

fetchState();
</script>
</body></html>
"""


class App:
    def __init__(
        self,
        root: Path,
        code: str,
        deck_code: str,
        seed: int,
        debug: bool,
        compiled: Optional[Path] = None,
        tokv1: Optional[Path] = None,
    ):
        self.root = root
        self.outdir = root / "sim_out"
        self.cards_db = load_cards_db(root, compiled_path=compiled, tokv1_path=tokv1)
        self.img = ImageLocator(root)
        self.ui_code = str(code)
        self.deck_code = str(deck_code)
        self.gs, self.rng = new_game(root, self.deck_code, seed=seed, debug=debug)
        self.save_trace()

    def save_trace(self):
        self.outdir.mkdir(parents=True, exist_ok=True)
        _write_text(self.outdir / "ui_trace.txt", "\n".join(self.gs.log) + ("\n" if self.gs.log else ""))

    def _cn2type(self) -> Dict[str, str]:
        cns: set = set()
        try:
            cns.update(self.gs.hand or [])
            cns.update(self.gs.green_room or [])
            cns.update(self.gs.set_zone or [])
            cns.update(self.gs.resolve_zone or [])
        except Exception:
            pass
        try:
            for _pos, v in (self.gs.stage or {}).items():
                if v and getattr(v, "cardnumber", None):
                    cns.add(v.cardnumber)
        except Exception:
            pass

        out: Dict[str, str] = {}
        for cn in sorted(cns):
            ci = _get_card(self.cards_db, cn)
            if ci and getattr(ci, "type", None):
                out[cn] = str(ci.type)
        return out

    def _all_cardnumbers_in_state(self) -> List[str]:
        """Collect all cardnumbers referenced by the current game state.

        Used by the UI to build cn->label/name maps. Must never throw.
        """
        gs = self.g.state
        cns: set[str] = set()

        def _add_from_iter(items: Any):
            if not items:
                return
            try:
                for it in items:
                    if it is None:
                        continue
                    if isinstance(it, str):
                        cns.add(it)
                    else:
                        cn = getattr(it, "cardnumber", None) or getattr(it, "cn", None)
                        if isinstance(cn, str) and cn:
                            cns.add(cn)
            except Exception:
                return

        # Common zones
        _add_from_iter(getattr(gs, "hand", None))
        _add_from_iter(getattr(gs, "green_room", None))
        _add_from_iter(getattr(gs, "set_zone", None))
        _add_from_iter(getattr(gs, "resolve_zone", None))
        _add_from_iter(getattr(gs, "deck", None))

        # Stage slots can be dict-like
        try:
            st = getattr(gs, "stage", None)
            if isinstance(st, dict):
                _add_from_iter(st.values())
        except Exception:
            pass

        # Pending prompts may include candidates / cards
        try:
            for item in getattr(gs, "pending", []) or []:
                if not isinstance(item, dict):
                    continue
                _add_from_iter(item.get("candidates"))
                _add_from_iter(item.get("cards"))
                _add_from_iter(item.get("shown"))
        except Exception:
            pass

        return sorted(cns)

    def _cn2name(self) -> Dict[str, str]:
        cns: set = set()
        try:
            cns.update(self.gs.hand or [])
            cns.update(self.gs.green_room or [])
            cns.update(self.gs.set_zone or [])
            cns.update(self.gs.resolve_zone or [])
        except Exception:
            pass
        try:
            for _pos, v in (self.gs.stage or {}).items():
                if v and getattr(v, "cardnumber", None):
                    cns.add(v.cardnumber)
        except Exception:
            pass

        out: Dict[str, str] = {}
        for cn in sorted(cns):
            ci = _get_card(self.cards_db, cn)
            if ci and ci.name:
                out[cn] = ci.name
        return out

    def _cn2label(self) -> Dict[str, str]:
        """UI label policy:
        - LIVE card: "<name>"
        - MEMBER card: "<exp>/<cost>/<name>" (exp = token before first '-')
        """
        cns: set[str] = set()
        for cn in self._all_cardnumbers_in_state():
            cns.add(cn)
        # Also include candidate options from pending prompts so popups can show names.
        for p in self.gs.pending:
            for opt in (p.get("options") or []):
                if isinstance(opt, str) and "PL!" in opt:
                    cns.add(opt)

        def _exp_token(cardnumber: str) -> str:
            try:
                s = cardnumber.split("!", 1)[1]
                return s.split("-", 1)[0]
            except Exception:
                return ""

        out: Dict[str, str] = {}
        cn2type = self._cn2type()
        for cn in sorted(cns):
            ci = _get_card(self.cards_db, cn)
            if not ci or not ci.name:
                continue
            t = cn2type.get(cn, "")
            if t == "LIVE":
                out[cn] = ci.name
            else:
                exp = _exp_token(cn)
                cost = getattr(ci, "cost", None)
                try:
                    cost_s = str(int(cost)) if cost is not None else "?"
                except Exception:
                    cost_s = "?"
                out[cn] = f"{exp}/{cost_s}/{ci.name}" if exp else f"{cost_s}/{ci.name}"
        return out

    def state_json(self) -> Dict[str, Any]:
        return {
            "root": self.gs.root,
            "code": self.ui_code,
            "deck_code": self.deck_code,
            "seed": self.gs.seed,
            "debug": self.gs.debug,
            "turn": self.gs.turn,
            "phase": self.gs.phase,
            "deck": self.gs.deck if self.gs.debug else ["?"] * len(self.gs.deck),
            "hand": self.gs.hand,
            "energy_active": self.gs.energy_active,
            "energy_wait": self.gs.energy_wait,
            "stage": {k: (asdict(v) if v else None) for k, v in self.gs.stage.items()},
            "green_room": self.gs.green_room,
            "set_zone": self.gs.set_zone,
            "resolve_zone": self.gs.resolve_zone,
            "pending": self.gs.pending,
            "cn2name": self._cn2name(),
            "cn2label": self._cn2label(),
            "cn2type": self._cn2type(),
            "stage_detail": {k: ({
                "cardnumber": v.cardnumber,
                "name": (_get_card(self.cards_db, v.cardnumber).name if _get_card(self.cards_db, v.cardnumber) else ""),
                "type": (_get_card(self.cards_db, v.cardnumber).type if _get_card(self.cards_db, v.cardnumber) else ""),
                "has_sac": _has_sacrifice_ability(_get_card(self.cards_db, v.cardnumber)),
            } if v else None) for k, v in self.gs.stage.items()},
            "log": self.gs.log,
        }

    def cmd(self, name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        mutating = name in {"play", "set", "yell", "attempt", "ack", "end_turn", "toggle_debug", "activate_to_green", "resolve_pending", "next"}
        if mutating and name != "toggle_debug":
            push_undo(self.gs, self.rng)

        if name == "play":
            cmd_play(self.gs, self.cards_db, int(payload.get("hand_idx", -1)), str(payload.get("pos", "")))
        elif name == "set":
            idxs = payload.get("indices", [])
            if not isinstance(idxs, list):
                idxs = []
            cmd_set(self.gs, self.rng, [int(x) for x in idxs])
        elif name == "yell":
            cmd_yell(self.gs, self.rng, self.cards_db)
        elif name == "attempt":
            cmd_attempt(self.gs, self.cards_db)
        elif name == "ack":
            cmd_ack(self.gs)
        elif name == "activate_to_green":
            cmd_activate_to_green(self.gs, self.cards_db, str(payload.get("pos", "")))
        elif name == "resolve_pending":
            cmd_resolve_pending(self.gs, self.cards_db, int(payload.get("idx", -1)), str(payload.get("choice", "")))
        elif name == "next":
            idxs = payload.get("indices", [])
            if not isinstance(idxs, list):
                idxs = []
            cmd_next(self.gs, self.rng, self.cards_db, [int(x) for x in idxs])
        elif name == "end_turn":
            cmd_end_turn(self.gs, self.rng)
        elif name == "undo":
            do_undo(self.gs, self.rng)
        elif name == "toggle_debug":
            self.gs.debug = not self.gs.debug
            self.gs.log.append(f"[DEBUG] debug={self.gs.debug}")
        elif name == "peek":
            n = _safe_int(payload.get("n", 5), 5)
            if not self.gs.debug:
                self.gs.log.append("[PEEK] enable debug first")
            else:
                top = self.gs.deck[:max(0, n)]
                self.gs.log.append("[PEEK] top: " + ", ".join(top))
        else:
            self.gs.log.append(f"[ERR] unknown cmd: {name}")

        self.save_trace()
        return self.state_json()


class Handler(BaseHTTPRequestHandler):
    app: App = None  # type: ignore

    def _send(self, code: int, content: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/":
            self._send(200, HTML.encode("utf-8"), "text/html; charset=utf-8")
            return
        if u.path == "/playmat":
            # Serve playmat.jpg from loveca root (next to scripts) if present.
            candidates = []
            try:
                here = Path(__file__).resolve()
                candidates.append(here.parents[1] / "playmat.jpg")  # loveca/playmat.jpg
            except Exception:
                pass
            candidates.append(Path.cwd() / "playmat.jpg")
            for p in candidates:
                if p and p.exists():
                    self._send(200, p.read_bytes(), "image/jpeg")
                    return
            self._send(404, b"", "text/plain; charset=utf-8")
            return

        if u.path == "/state":
            data = json.dumps(self.app.state_json(), ensure_ascii=False).encode("utf-8")
            self._send(200, data, "application/json; charset=utf-8")
            return
        if u.path == "/img":
            qs = parse_qs(u.query)
            cn = unquote((qs.get("cn", [""])[0] or "").strip())
            p = self.app.img.find(cn)
            if p and p.exists():
                ctype = "image/png"
                if str(p).lower().endswith(".jpg") or str(p).lower().endswith(".jpeg"):
                    ctype = "image/jpeg"
                self._send(200, p.read_bytes(), ctype)
            else:
                self._send(404, b"", "text/plain")
            return
        self._send(404, b"not found", "text/plain; charset=utf-8")

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/cmd":
            self._send(404, b"not found", "text/plain; charset=utf-8")
            return
        n = int(self.headers.get("Content-Length", "0") or "0")
        body = self.rfile.read(n) if n > 0 else b"{}"
        try:
            obj = json.loads(body.decode("utf-8"))
        except Exception:
            obj = {}
        cmd = str(obj.get("cmd", "")).strip()
        payload = obj.get("payload", {}) or {}
        if not isinstance(payload, dict):
            payload = {}
        out = self.app.cmd(cmd, payload)
        data = json.dumps(out, ensure_ascii=False).encode("utf-8")
        self._send(200, data, "application/json; charset=utf-8")

