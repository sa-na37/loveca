Install / overwrite (from your project folder, e.g. ~/Desktop/gsim/loveca):

  unzip -o ~/Downloads/llocg_ui_split_fixed.zip -d .
  python3 -m py_compile llocg_ui_web.py llocg_ui/*.py

Run:
  python3 llocg_ui_web.py --root ./llocg_db_out_full --code 7QEC8 --port 8000

Notes:
- --root should point to the DB output folder (llocg_db_out_full).
- cards_compiled_*.json / cards_min_tokv1.* は root 配下から自動検出（明示したい場合は --compiled/--tokv1）。
