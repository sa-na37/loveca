# -*- coding: utf-8 -*-
"""
llocg_ui.images

Prefer loading ../images.py if it exists (flat layout). If that file uses relative imports
and fails, fall back to a minimal ImageLocator sufficient for /img?cn=... endpoints.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Any
import importlib.util
from importlib.machinery import SourceFileLoader
from types import ModuleType

_OUTER_NAME = "_llocg_ui_outer_images"

def _try_load_outer_images() -> Optional[ModuleType]:
    here = Path(__file__).resolve()
    outer = here.parents[1] / "images.py"
    if not outer.exists():
        return None
    spec = importlib.util.spec_from_loader(_OUTER_NAME, SourceFileLoader(_OUTER_NAME, str(outer)))
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    except Exception:
        return None
    return mod

_outer = _try_load_outer_images()

if _outer is not None:
    # re-export
    def __getattr__(name: str) -> Any:
        if hasattr(_outer, name):
            return getattr(_outer, name)
        raise AttributeError(name)

    def __dir__() -> list[str]:
        return sorted(set(globals().keys()) | set(dir(_outer)))
else:
    class ImageLocator:
        """
        Minimal image resolver.
        Expected folder structure under <root>/card_images/:
          - <cardnumber>.jpg (or .png/.jpeg/.webp)
          - back.jpeg (optional)
          - playmat.jpg (optional)
        """
        def __init__(self, root: Path):
            self.root = Path(root)
            self.img_dir = self.root / "card_images"

        def find(self, cn: str) -> Optional[Path]:
            cn = (cn or "").strip()
            if not cn:
                return None
            # direct lookup
            for ext in (".jpg", ".jpeg", ".png", ".webp"):
                p = self.img_dir / f"{cn}{ext}"
                if p.exists():
                    return p
            return None

        def playmat(self) -> Optional[Path]:
            p = self.root / "playmat.jpg"
            if p.exists():
                return p
            p = self.img_dir / "playmat.jpg"
            if p.exists():
                return p
            return None

        def back(self) -> Optional[Path]:
            for name in ("back.jpeg", "back.jpg", "back.png"):
                p = self.img_dir / name
                if p.exists():
                    return p
            return None
