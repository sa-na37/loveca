# -*- coding: utf-8 -*-
"""llocg_ui.db (package wrapper)

このプロジェクトは環境によって次の2パターンの配置が混在します。
  (A) package:  llocg_ui/db.py, engine.py, images.py, server.py
  (B) flat:     db.py, engine.py, images.py, server.py （runスクリプトと同じ階層）

Web UI は package import（from .db import ...）前提ですが、実体が flat 側にある場合に備えて
この wrapper は ../db.py を動的にロードして必要シンボルを再公開します。

重要:
- outer db.py は dataclasses を使っているため、exec_module() 前に sys.modules に登録しないと
  dataclasses 側が cls.__module__ を解決できず AttributeError になります。
"""

from __future__ import annotations

import importlib.util
import sys
from importlib.machinery import SourceFileLoader
from pathlib import Path
from types import ModuleType
from typing import Any, Optional

_OUTER_NAME = "_llocg_ui_outer_db"


def _load_outer_db() -> Optional[ModuleType]:
    here = Path(__file__).resolve()
    outer = here.parents[1] / "db.py"  # ../db.py
    if not outer.exists():
        return None

    spec = importlib.util.spec_from_loader(
        _OUTER_NAME,
        SourceFileLoader(_OUTER_NAME, str(outer)),
    )
    if spec is None or spec.loader is None:
        return None

    mod = importlib.util.module_from_spec(spec)
    # dataclasses 等が sys.modules[cls.__module__] を参照するので事前登録が必須
    sys.modules[_OUTER_NAME] = mod
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    return mod


_outer = _load_outer_db()


def __getattr__(name: str) -> Any:
    if _outer is not None and hasattr(_outer, name):
        return getattr(_outer, name)
    raise AttributeError(name)


def __dir__() -> list[str]:
    keys = set(globals().keys())
    if _outer is not None:
        keys |= set(dir(_outer))
    return sorted(keys)


# ---- Required exports (server/images depend on these) ----
if _outer is not None:
    # 重要シンボルは明示的に再公開（他は __getattr__ にフォールバック）
    load_cards_db = getattr(_outer, "load_cards_db", None)
    _read_json = getattr(_outer, "_read_json", None)
    _write_text = getattr(_outer, "_write_text", None)
    _cardno_variants = getattr(_outer, "_cardno_variants", None)
    CardInfo = getattr(_outer, "CardInfo", None)
    _get_card = getattr(_outer, "_get_card", None)
else:

    def _missing(*_a: Any, **_k: Any) -> Any:
        raise RuntimeError(
            "llocg_ui.db: outer db.py が見つかりません。 "
            "run_llocg_ui_web.py と同階層に db.py がある想定です。"
        )

    load_cards_db = _missing
    _read_json = _missing
    _write_text = _missing
    _cardno_variants = _missing
    CardInfo = None
    _get_card = _missing
