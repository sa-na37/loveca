# -*- coding: utf-8 -*-
"""
llocg_ui.engine (package wrapper)

Loads ../engine.py (flat layout) and re-exports its symbols.
"""
from __future__ import annotations

import importlib.util
from importlib.machinery import SourceFileLoader
from pathlib import Path
from types import ModuleType
from typing import Any, Optional

_OUTER_NAME = "_llocg_ui_outer_engine"

def _load_outer_engine() -> Optional[ModuleType]:
    here = Path(__file__).resolve()
    outer = here.parents[1] / "engine.py"  # ../engine.py
    if not outer.exists():
        return None
    spec = importlib.util.spec_from_loader(_OUTER_NAME, SourceFileLoader(_OUTER_NAME, str(outer)))
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore[attr-defined]
    return mod

_outer = _load_outer_engine()

def __getattr__(name: str) -> Any:
    if _outer is not None and hasattr(_outer, name):
        return getattr(_outer, name)
    raise AttributeError(name)

def __dir__() -> list[str]:
    keys = set(globals().keys())
    if _outer is not None:
        keys |= set(dir(_outer))
    return sorted(keys)

if _outer is None:
    def _missing(*_a: Any, **_k: Any) -> Any:
        raise RuntimeError("llocg_ui.engine: outer engine.py not found one directory above. "
                           "Expected ../engine.py next to run_llocg_ui_web.py")
    new_game = _missing
