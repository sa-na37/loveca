#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run LLCG web UI (robust runner).

Usage:
  python3 run_llocg_ui_web.py --root ./llocg_db_out_full --code 1RCBL --port 8000
"""

import argparse
import sys
from pathlib import Path

def _add_paths():
    here = Path(__file__).resolve().parent
    # project root (outer folder)
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    # package folder (here/llocg_ui)
    pkg = here / "llocg_ui"
    if pkg.exists() and str(pkg) not in sys.path:
        sys.path.insert(0, str(pkg))

_add_paths()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True, help="DB root (e.g., ./llocg_db_out_full)")
    p.add_argument("--code", required=True, help="Deck code (e.g., 1RCBL)")
    p.add_argument("--port", type=int, default=8000)
    args = p.parse_args()

    # Import after sys.path setup
    try:
        from llocg_ui.server import App, Handler  # package layout
    except Exception:
        from server import App, Handler  # flat layout fallback

    app = App(root_dir=args.root, deck_code=args.code)
    Handler.app = app

    import socketserver
    from http.server import ThreadingHTTPServer

    srv = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"[UI] open: http://127.0.0.1:{args.port}/")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()

if __name__ == "__main__":
    main()
